#pragma once
#include "LoRaProtocol.h"

namespace qp1ng {
// Local scheduling only. No changes to the deployed over-the-air framing.
// Bounds fit inside the existing Android 5s + 2s/fragment completion timeout.
struct RadioAccess {
    bool active = false;
    uint32_t queuedAt = 0, budgetMs = 0;
    uint8_t deferrals = 0;
    bool burstHold = false;
    uint32_t burstUntil = 0;
    static uint32_t initialDelay(uint32_t random) { return 40u + random % 240u; }
    void begin(uint32_t now, uint8_t chunks) {
        active = true; queuedAt = now;
        budgetMs = 3000u + 1500u * chunks; deferrals = 0; burstHold = false;
    }
    void reset() { active = false; deferrals = 0; burstHold = false; }
    bool expired(uint32_t now) const { return active && elapsed(now, queuedAt, budgetMs); }
    uint32_t backoff(uint32_t random) {
        if (deferrals < 5) ++deferrals;
        const uint32_t window = 80u << deferrals;
        return 40u + random % (window > 640u ? 640u : window);
    }
    void progressed() { deferrals = 0; }
    void receivedFragment(uint32_t now, uint8_t index, uint8_t count, uint32_t random) {
        if (!active || !count || count > MaxChunks || index >= count) return;
        burstHold = index + 1 < count;
        // Legacy peers pause up to 600 ms between fragments. Let that burst
        // continue instead of competing in its gaps. The overall deadline stays.
        burstUntil = now + 750u + random % 150u;
    }
    bool receivingBurst(uint32_t now) const { return active && burstHold && !due(now, burstUntil); }
};

// An RX preamble/header is latched in the SX1262. Give an in-flight frame time
// to finish before entering CAD; do not let a stale flag stall the queue forever.
struct ReceiveGuard {
    enum class Action { Free, Hold, ClearPreamble, RestartReceive };
    bool tracking = false, headerSeen = false;
    uint32_t since = 0;
    void reset() { tracking = headerSeen = false; since = 0; }
    Action observe(uint32_t now, bool preamble, bool header, uint32_t maxFrameMs) {
        if (!preamble && !header) { reset(); return Action::Free; }
        if (!tracking || (header && !headerSeen)) {
            tracking = true; headerSeen = header; since = now;
        }
        if (!elapsed(now, since, maxFrameMs + 80u)) return Action::Hold;
        const bool hadHeader = headerSeen;
        reset();
        return hadHeader ? Action::RestartReceive : Action::ClearPreamble;
    }
};

// Suppress ONLY an unsent relay, after hearing every identical payload fragment
// from a further relay (lower hop budget). A 32-bit ID alone is not sufficient.
// This is duplicate suppression, not authentication of other radio nodes.
struct RelayEvidence {
    uint32_t matched = 0;
    void reset() { matched = 0; }
    bool observe(const uint8_t* frame, size_t length, const uint8_t* queued,
                 size_t queuedLength, uint32_t id, uint8_t remainingHops) {
        if (!queuedLength || queuedLength > MaxPayload || length < 9 || length > Chunk + 8 ||
            frame[0] != 0x55 || frame[1] > remainingHops) return false;
        const uint32_t heard = uint32_t(frame[2]) | uint32_t(frame[3]) << 8 |
            uint32_t(frame[4]) << 16 | uint32_t(frame[5]) << 24;
        const uint8_t count = uint8_t((queuedLength + Chunk - 1) / Chunk), index = frame[6];
        if (heard != id || frame[7] != count || index >= count) return false;
        const size_t offset = index * Chunk;
        const size_t bytes = queuedLength - offset < Chunk ? queuedLength - offset : Chunk;
        if (length != bytes + 8 || memcmp(queued + offset, frame + 8, bytes) != 0) return false;
        matched |= uint32_t(1) << index;
        const uint32_t all = count == 32 ? UINT32_MAX : (uint32_t(1) << count) - 1;
        return matched == all;
    }
};
} // namespace qp1ng
