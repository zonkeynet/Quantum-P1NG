#pragma once
#include "LoRaProtocol.h"

namespace qp1ng {
// Reserve enough FIFO space for the largest production control reply (DIAG).
// A full data line must fit before it is written: HWCDC::write may be partial.
inline bool usbOutputReady(int available, size_t bytes, size_t replyReserve) {
    return available >= 0 && size_t(available) >= bytes + replyReserve;
}

struct UsbOutputWait {
    bool waiting = false;
    uint32_t since = 0;
    void progress() { waiting = false; }
    bool expired(uint32_t now) {
        if (!waiting) { waiting = true; since = now; }
        return elapsed(now, since, 2000);
    }
};
} // namespace qp1ng
