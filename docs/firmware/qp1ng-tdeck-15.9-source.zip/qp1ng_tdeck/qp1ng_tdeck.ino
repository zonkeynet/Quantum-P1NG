/*
 * =========================================================================
 * QUANTUM P1NG - LoRa FIELD DECK v15.9
 * Core Compatibility: ESP32 SDK 2.0.14
 * Freq: 433 MHz | Bounded channel access, managed relays, opaque phone bridge
 * 
 * Copyright © 2026 ZonkeyNet. All rights reserved.
 * =========================================================================
 */


#include <Arduino.h>
#include <SPI.h>
#include <Wire.h>
#include <TFT_eSPI.h>
#include <RadioLib.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>
#include <esp_gatts_api.h>
#include <string.h>
#include "LoRaProtocol.h"
#include "RadioAccess.h"
#include "UsbOutput.h"
#include "TDeckModel.h"
#include <ctype.h>
#include <freertos/FreeRTOS.h>
#include <freertos/queue.h>
#if defined(ARDUINO_ARCH_ESP32)
#include "USB.h"
#endif

// --- LILYGO T-DECK HARDWARE PINS ---
#define BOARD_POWERON       10
#define RADIO_CS_PIN        9
#define RADIO_DIO1_PIN      45
#define RADIO_RST_PIN       17
#define RADIO_BUSY_PIN      13
#define BOARD_SDCARD_CS     39
#define BOARD_TFT_CS        12
#define BOARD_TFT_BACKLIGHT 42
#define BOARD_SPI_SCK       40
#define BOARD_SPI_MOSI      41
#define BOARD_SPI_MISO      38
#define BOARD_I2C_SDA       18
#define BOARD_I2C_SCL       8
#define BOARD_BAT_ADC       4

// Trackball
#define TRACKBALL_UP        3
#define TRACKBALL_DOWN      15
#define TRACKBALL_LEFT      1
#define TRACKBALL_RIGHT     2
#define TRACKBALL_CLICK     0

// --- BLE UUIDs ---
#define SERVICE_UUID           "6E400001-B5A3-F393-E0A9-E50E24DCCA9E"
#define CHARACTERISTIC_UUID_RX "6E400002-B5A3-F393-E0A9-E50E24DCCA9E"
#define CHARACTERISTIC_UUID_TX "6E400003-B5A3-F393-E0A9-E50E24DCCA9E"

// --- CYBERPUNK PALETTE ---
#define FW_VERSION "15.9"
#define FW_PROFILE "FIELD PRO"
#define USB_DEBUG_LOG 0
#define USB_PROTOCOL_ENABLED 1
#define USB_COMMAND_MAX_LEN 560
#define USB_HOST_FRAME_BUFFER_SIZE 260
#define CP_AMBER 0xFD20
#define CP_BLACK 0x0000
#define CP_GREEN 0x07E0
#define CP_RED   0xF800
#define CP_BLUE  0x07FF 
#define CP_DIM   0x4A69 
#define CP_GRID  0x18E3 
#define CP_PANEL 0x0841
#define CP_WHITE 0xFFFF

#if USB_PROTOCOL_ENABLED && defined(ARDUINO_ARCH_ESP32) && !ARDUINO_USB_CDC_ON_BOOT
USBCDC Qp1ngUsbSerial;
#endif

// --- GLOBALS ---
TFT_eSPI tft = TFT_eSPI();
SX1262 radio = new Module(RADIO_CS_PIN, RADIO_DIO1_PIN, RADIO_RST_PIN, RADIO_BUSY_PIN);
BLEServer *pServer = NULL;
BLECharacteristic * pTxCharacteristic;
BLECharacteristic *pStatusCharacteristic = nullptr;
portMUX_TYPE statusMux = portMUX_INITIALIZER_UNLOCKED;
uint8_t radioStatusValue[16] = {'Q', 'L', 3, 0};
int8_t appliedTxPower = qp1ng::DefaultTxPower;
int8_t hostTxPower[3] = {qp1ng::DefaultTxPower, qp1ng::DefaultTxPower, qp1ng::DefaultTxPower};
int8_t requestedTxPower = qp1ng::DefaultTxPower;
uint8_t powerResult = 0, powerSequence = 0;
volatile esp_gatt_if_t radioGattIf = ESP_GATT_IF_NONE;

void observeGattRegistration(esp_gatts_cb_event_t event, esp_gatt_if_t interface, esp_ble_gatts_cb_param_t* param) {
    if (event == ESP_GATTS_REG_EVT && param->reg.status == ESP_GATT_OK) radioGattIf = interface;
}

volatile bool deviceConnected = false;
volatile bool bleLinkConnected = false;
volatile uint16_t peerMtu = 23;
volatile bool bleDisconnected = false;
volatile uint32_t pendingPasskey = 0;
volatile bool bleOverflow = false;
bool radioReady = false;
uint32_t txStartedAt = 0;
const char* lastTxState = "idle";
qp1ng::HostAssembler hostAssembler;
struct BleInput { uint16_t size; uint8_t bytes[260]; };
StaticQueue_t bleQueueControl;
uint8_t bleQueueStorage[16 * sizeof(BleInput)];
QueueHandle_t bleQueue = nullptr;
bool oldDeviceConnected = false;
uint32_t sessionPin; 
uint64_t chipMac; 

volatile bool radioActionDone = false;
volatile bool isTransmitting = false;

#if defined(ESP8266) || defined(ESP32)
  void IRAM_ATTR setFlag(void) { radioActionDone = true; }
#else
  void setFlag(void) { radioActionDone = true; }
#endif

// --- MESH ENGINE & SWARM PROTOCOL ---
#define MESH_MAGIC_BYTE 0x55 
#define MAX_HOPS 3
#define HASH_BUFFER_SIZE 250
#define MAX_PAYLOAD_PER_CHUNK 220 
#define RX_CHUNK_TIMEOUT_MS 60000  
#define MAX_CHUNKS_PER_MSG 32
#define MAX_LORA_PAYLOAD_BYTES (MAX_PAYLOAD_PER_CHUNK * MAX_CHUNKS_PER_MSG)
#define LORA_TX_BUFFER_SIZE MAX_LORA_PAYLOAD_BYTES
#define RX_SESSION_BUFFER_SIZE MAX_LORA_PAYLOAD_BYTES
uint32_t seenHashes[HASH_BUFFER_SIZE];
uint32_t seenAt[HASH_BUFFER_SIZE];
bool seenValid[HASH_BUFFER_SIZE]{};
int seenIndex = 0;
int totalRelays = 0; 
float networkPressure = 0.0;
unsigned long lastPressureUpdate = 0;

uint8_t loraTxBuffer[LORA_TX_BUFFER_SIZE];
uint8_t meshTxBuffer[256]; 
uint8_t usbHostFrameBuffer[USB_HOST_FRAME_BUFFER_SIZE];

uint16_t expectedTotalLen = 0;
uint16_t currentOffset = 0;

// --- MULTI-SESSION RX MANAGER ---
#define MAX_RX_SESSIONS 3

using RxSession = qp1ng::RadioAssembly;
RxSession rxSessions[MAX_RX_SESSIONS];
void resetRxSession(int i) { rxSessions[i].reset(); }

int getRxSession(uint32_t hash) {
    for(int i=0; i<MAX_RX_SESSIONS; i++) {
        if(rxSessions[i].active && rxSessions[i].hash == hash) return i;
    }
    for(int i=0; i<MAX_RX_SESSIONS; i++) {
        if(!rxSessions[i].active) {
            resetRxSession(i);
            return i;
        }
    }
    return -1; 
}

// --- TX STATE MACHINE ---
volatile bool inTxFragMode = false;
volatile uint8_t txTotalChunks = 0;
volatile uint8_t txCurrentChunk = 0;
volatile uint8_t txCurrentHops = 0; 
volatile unsigned long nextTxTime = 0;
uint32_t currentTxHash = 0;
uint32_t lastHostHash = 0;
uint16_t lastHostLength = 0;
bool currentTxIsHost = false;
bool currentTxIsRelay = false;
bool channelScanActive = false;
uint32_t channelScanStarted = 0;
uint32_t radioRecoveryAt = 0;
uint8_t radioRecoveryAttempts = 0;
uint32_t maxFrameMs = 700;
qp1ng::RadioAccess radioAccess;
qp1ng::ReceiveGuard receiveGuard;
qp1ng::RelayEvidence relayEvidence;
uint32_t statChannelScans = 0, statChannelDeferrals = 0, statRelayCancelled = 0;
uint32_t statRadioErrors = 0, statTxAirtimeMs = 0;
uint32_t statUsbOutputDrops = 0;
#if QP1NG_TEST_HOOKS
uint32_t testBusyUntil = 0;
bool testChannelBusy = false, testLoseCadIrq = false;
#endif

// --- LOCAL TELEMETRY (display-only, no protocol impact) ---
uint32_t statBleRxFrames = 0;
uint32_t statBleTxFrames = 0;
uint32_t statRfTxSequences = 0;
uint32_t statRfRxSequences = 0;
uint32_t statRelayQueued = 0;
uint32_t statRfChunksRx = 0;
uint16_t lastTxBytes = 0;
uint16_t lastRxBytes = 0;
uint8_t lastTxChunks = 0;
uint8_t lastRxChunks = 0;
unsigned long lastIntelMs = 0;
unsigned long lastUsbHeartbeatMs = 0;
String serialCommandBuffer;
#if USB_PROTOCOL_ENABLED && defined(ARDUINO_ARCH_ESP32) && !ARDUINO_USB_CDC_ON_BOOT
String cdcCommandBuffer;
#endif

bool ingestHostFrame(uint8_t* data, int rxLen, const char* sourceLabel);

void recordExperienceEvent(const char* text, uint16_t color);
bool handleLocalUsbCommand(const String& cmd, Print& out);
bool localModeAllowsTx();
bool localRelayEnabled();
uint8_t localHopBudget(uint8_t legacy);
void handleRoomPacket(const uint8_t* packet, size_t length);
void notifyLocalTx(bool success);
void serviceExperience();
bool resumeRadioReceive();
void finishRadioTx(bool success);


// =========================================================================
// HARDWARE SENSORS LOGIC
// =========================================================================
int getBatteryPct() {
    float voltage = (analogRead(BOARD_BAT_ADC) / 4095.0) * 3.3 * 2.0;
    int pct = map((int)(voltage * 100), 320, 420, 0, 100);
    return constrain(pct, 0, 100);
}

// =========================================================================
// MESH UTILITIES 
// =========================================================================
uint32_t calculateHash(uint8_t* data, size_t length) {
    uint32_t hash = 2166136261u;
    for (size_t i = 0; i < length; i++) { hash ^= data[i]; hash *= 16777619; }
    return hash;
}

bool isHashSeen(uint32_t hash) {
    for (int i = 0; i < HASH_BUFFER_SIZE; ++i) {
        if (seenValid[i] && qp1ng::elapsed(millis(), seenAt[i], 120000)) seenValid[i] = false;
        if (seenValid[i] && seenHashes[i] == hash) return true;
    }
    return false;
}
void markHashSeen(uint32_t hash) {
    seenHashes[seenIndex] = hash; seenAt[seenIndex] = millis(); seenValid[seenIndex] = true;
    seenIndex = (seenIndex + 1) % HASH_BUFFER_SIZE;
}


int calculateAdaptiveDelay(float rssi, float snr, uint32_t payloadHash) {
    // Weaker receptions get an earlier chance to extend coverage. Battery and
    // congestion delay forwarding instead of randomly discarding the only route.
    const float quality = (constrain(snr, -15.0f, 15.0f) + 15.0f) / 30.0f;
    const uint32_t nearPenalty = rssi > -60.0f ? 80u : 0u;
    const uint32_t batteryPenalty = getBatteryPct() < 20 ? 150u : 0u;
    return 80 + int(quality * 320.0f) + nearPenalty + batteryPenalty +
        uint32_t(networkPressure * 4) + ((esp_random() ^ payloadHash) % 160);
}

// =========================================================================
// UI ENGINE
// =========================================================================
int activeRxSessions() {
    int active = 0;
    for(int i=0; i<MAX_RX_SESSIONS; i++) {
        if(rxSessions[i].active) active++;
    }
    return active;
}

void serialDebugLog(const String&) {}
void serialHeartbeat() {}

void writeTxStatus(Print &out) {
    out.print("QP1NG_TDECK_TX|hash="); out.print(lastHostHash, HEX);
    out.print("|state="); out.println(lastTxState);
}

void updateRadioStatus() {
    uint8_t value[16] = {'Q', 'L', 3, uint8_t(!radioReady ? 3 : (strcmp(lastTxState, "queued") == 0 ? 1 :
        (strcmp(lastTxState, "sent") == 0 ? 2 : (strcmp(lastTxState, "error") == 0 ? 3 : 0))))};
    for (int i = 0; i < 4; ++i) value[4 + i] = lastHostHash >> (8 * i);
    value[8] = lastHostLength >> 8; value[9] = lastHostLength;
    value[10] = radioReady ? 1 : 0; value[11] = inTxFragMode ? 1 : 0;
    value[12] = uint8_t(appliedTxPower); value[13] = powerResult;
    value[14] = uint8_t(requestedTxPower); value[15] = powerSequence;
    portENTER_CRITICAL(&statusMux);
    memcpy(radioStatusValue, value, sizeof(value));
    portEXIT_CRITICAL(&statusMux);
}

bool setRadioPower(int8_t power) {
    if (!radioReady || inTxFragMode || isTransmitting) return false;
    if (appliedTxPower == power) return true;
    if (radio.standby() != RADIOLIB_ERR_NONE) return false;
    const int state = radio.setOutputPower(power);
    if (state == RADIOLIB_ERR_NONE) appliedTxPower = power;
    resumeRadioReceive();
    return state == RADIOLIB_ERR_NONE && radioReady;
}

void applyPowerCommand(const char* command, size_t length, uint8_t source) {
    int8_t power = qp1ng::DefaultTxPower;
    ++powerSequence;
    if (!qp1ng::parseTxPower(command, length, power)) powerResult = 3;
    else {
        requestedTxPower = power;
        if (inTxFragMode || isTransmitting || hostAssembler.total) powerResult = 2;
        else if (!setRadioPower(power)) powerResult = 4;
        else { hostTxPower[source] = power; powerResult = 1; }
    }
    updateRadioStatus();
}

void writePowerStatus(Print& out) {
    out.print("QP1NG_TDECK_POWER|state=");
    out.print(powerResult == 1 ? "ok" : (powerResult == 2 ? "busy" : (powerResult == 3 ? "invalid" : "error")));
    out.print("|applied="); out.print(appliedTxPower);
    out.print("|max=22|seq="); out.println(powerSequence);
}

void writeUsbIdentity(Print &out) {
    out.print("QP1NG_TDECK|v=");
    out.print(FW_VERSION);
    out.print("|profile=");
    out.print(FW_PROFILE);
    out.print("|radio=SX1262|freq=433MHz|proto=mesh-v15.4|usb=frame-rx|host=3|power=");
    out.print(appliedTxPower); out.print("|power_max=22|mtu=");
    out.print(peerMtu);
    out.print("|ble=");
    out.print(deviceConnected ? "linked" : "idle");
    out.print("|rf=");
    out.print(!radioReady ? "error" : (inTxFragMode ? "tx" : "rx"));
    out.print("|rx_seq=");
    out.print((unsigned long)statRfRxSequences);
    out.print("|tx_seq=");
    out.print((unsigned long)statRfTxSequences);
    out.println();
}

int hexNibble(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

bool decodeHexFrame(const String &hex, uint8_t *out, size_t maxLen, size_t &outLen) {
    int hexLen = hex.length();
    if (hexLen <= 0 || (hexLen % 2) != 0) return false;
    size_t decodedLen = hexLen / 2;
    if (decodedLen > maxLen) return false;

    for (size_t i = 0; i < decodedLen; i++) {
        int hi = hexNibble(hex.charAt(i * 2));
        int lo = hexNibble(hex.charAt(i * 2 + 1));
        if (hi < 0 || lo < 0) return false;
        out[i] = (uint8_t)((hi << 4) | lo);
    }
    outLen = decodedLen;
    return true;
}

void handleUsbCommand(const String &command, Print &out) {
    String cmd = command;
    cmd.trim();
    if (cmd.length() == 0) return;

    if (cmd == "QP1NG_USB_HELLO" || cmd == "QP1NG_USB_STATUS") {
        writeUsbIdentity(out);
    } else if (cmd == "QP1NG_USB_TX_STATUS") {
        writeTxStatus(out);
    } else if (cmd == "QP1NG_USB_PING") {
        out.println("QP1NG_TDECK_PONG");
    } else if (cmd.startsWith("TX_POWER")) {
        applyPowerCommand(cmd.c_str(), cmd.length(), 1);
        writePowerStatus(out);
    } else if (cmd.startsWith("QP1NG_USB_FRAME|")) {
        String hex = cmd.substring(16);
        size_t decodedLen = 0;
        if (!decodeHexFrame(hex, usbHostFrameBuffer, USB_HOST_FRAME_BUFFER_SIZE, decodedLen) || decodedLen < 5) {
            out.println("QP1NG_TDECK_ERR|bad_usb_frame");
            return;
        }
        if (ingestHostFrame(usbHostFrameBuffer, (int)decodedLen, "USB")) {
            out.print("QP1NG_TDECK_ACK|usb_frame|seq=");
            out.println((uint16_t(usbHostFrameBuffer[2]) << 8) | usbHostFrameBuffer[3]);
        } else {
            out.println("QP1NG_TDECK_ERR|usb_frame_rejected");
        }
    } else if (handleLocalUsbCommand(cmd, out)) {
        // Local diagnostics are separate from the radio/host framing.
    } else if (cmd.startsWith("QP1NG_")) {
        out.println("QP1NG_TDECK_ERR|unsupported");
    }
}

#if QP1NG_TEST_HOOKS
constexpr size_t UsbReplyReserve = 1536; // Private framebuffer row, never shipped.
#else
constexpr size_t UsbReplyReserve = 768;
#endif
bool usbOutputReady(Print &out, size_t bytes = 0) {
#if defined(ARDUINO_ARCH_ESP32) && ARDUINO_USB_CDC_ON_BOOT && ARDUINO_USB_MODE
    if (&out == &Serial) return qp1ng::usbOutputReady(out.availableForWrite(), bytes, UsbReplyReserve);
#endif
    return true; // Preserve other serial implementations; this target uses HWCDC.
}

void drainUsbCommands(Stream &stream, String &buffer, bool &dropping) {
    // Bound work per loop so a noisy USB host cannot starve the radio IRQ handler.
    for (int count = 0; count < 640 && stream.available() > 0; ++count) {
        if (!usbOutputReady(stream)) break; // Leave complete commands queued until their reply fits.
        char c = char(stream.read());
        if (c == '\n' || c == '\r') {
            if (!dropping) handleUsbCommand(buffer, stream);
            buffer = ""; dropping = false;
        } else if (!dropping) {
            if (buffer.length() < USB_COMMAND_MAX_LEN && c >= ' ' && c <= '~') buffer += c;
            else { buffer = ""; dropping = true; stream.println("QP1NG_TDECK_ERR|line_too_long"); }
        }
    }
}
void processUsbCommands() {
    static bool serialDropping = false;
    drainUsbCommands(Serial, serialCommandBuffer, serialDropping);
#if USB_PROTOCOL_ENABLED && defined(ARDUINO_ARCH_ESP32) && !ARDUINO_USB_CDC_ON_BOOT
    static bool cdcDropping = false;
    drainUsbCommands(Qp1ngUsbSerial, cdcCommandBuffer, cdcDropping);
#endif
}

void consoleLog(String msg, uint16_t color = CP_AMBER) {
    recordExperienceEvent(msg.c_str(), color);
}

// =========================================================================
// BLE SYMMETRIC SENDER
// =========================================================================
void writeHexByte(Print &out, uint8_t value) {
    const char hex[] = "0123456789ABCDEF";
    out.print(hex[(value >> 4) & 0x0F]);
    out.print(hex[value & 0x0F]);
}

void sendUsbFrameStream(Print &out, uint8_t* payload, uint16_t totalLen) {
    if (totalLen == 0) return;

    uint16_t offset = 0;
    uint16_t seqId = 0;
    uint8_t frame[5 + MAX_PAYLOAD_PER_CHUNK];

    while (offset < totalLen) {
        uint16_t chunkSize = min((int)MAX_PAYLOAD_PER_CHUNK, (int)(totalLen - offset));
        uint8_t flags = 0x00;
        if (offset == 0) flags |= 0x01;
        if (offset + chunkSize >= totalLen) flags |= 0x02;

        frame[0] = (totalLen >> 8) & 0xFF;
        frame[1] = totalLen & 0xFF;
        frame[2] = (seqId >> 8) & 0xFF;
        frame[3] = seqId & 0xFF;
        frame[4] = flags;
        memcpy(frame + 5, payload + offset, chunkSize);

        out.print("QP1NG_USB_RX_FRAME|");
        for (uint16_t i = 0; i < chunkSize + 5; i++) {
            writeHexByte(out, frame[i]);
        }
        out.println();

        offset += chunkSize;
        seqId++;
        delay(4);
    }
}

// Two bounded deliveries; no multi-second BLE notification loop in the radio handler.
struct HostDelivery {
    uint8_t bytes[MAX_LORA_PAYLOAD_BYTES];
    uint16_t length = 0, usbOffset = 0, bleOffset = 0, usbSeq = 0, bleSeq = 0;
    uint32_t nextBle = 0;
    bool usb = false, ble = false;
    qp1ng::UsbOutputWait usbWait;
};
uint16_t deliveryFrame(const HostDelivery &d, uint8_t* out, uint16_t offset, uint16_t seq, uint16_t maximum);
HostDelivery deliveries[2];
uint8_t deliveryHead = 0, deliveryCount = 0;
bool enqueueDelivery(const uint8_t* data, uint16_t length) {
    if (deliveryCount == 2) return false;
    HostDelivery &d = deliveries[(deliveryHead + deliveryCount) % 2];
    memcpy(d.bytes, data, length); d.length = length;
    d.usbOffset = d.bleOffset = d.usbSeq = d.bleSeq = 0; d.nextBle = 0; d.usbWait.progress();
    d.usb = bool(Serial);
#if USB_PROTOCOL_ENABLED && defined(ARDUINO_ARCH_ESP32) && !ARDUINO_USB_CDC_ON_BOOT
    d.usb = d.usb || bool(Qp1ngUsbSerial);
#endif
    d.ble = deviceConnected; ++deliveryCount; return true;
}
bool writeUsbDelivery(Print &out, const uint8_t* frame, size_t size) {
    // One write avoids interleaving prefix/data and is bounded to one USB frame.
    char line[2 * 225 + 22];
    const char* prefix = "QP1NG_USB_RX_FRAME|";
    const char* digits = "0123456789ABCDEF";
    size_t n = strlen(prefix); memcpy(line, prefix, n);
    for (size_t i = 0; i < size; ++i) { line[n++] = digits[frame[i] >> 4]; line[n++] = digits[frame[i] & 15]; }
    line[n++] = '\n';
    if (!usbOutputReady(out, n)) return false;
    return out.write(reinterpret_cast<uint8_t*>(line), n) == n;
}
uint16_t deliveryFrame(const HostDelivery &d, uint8_t* out, uint16_t offset, uint16_t seq, uint16_t maximum) {
    uint16_t count = min(maximum, uint16_t(d.length - offset));
    out[0] = d.length >> 8; out[1] = d.length; out[2] = seq >> 8; out[3] = seq;
    out[4] = (offset == 0 ? 1 : 0) | (offset + count == d.length ? 2 : 0);
    memcpy(out + 5, d.bytes + offset, count); return count;
}
void serviceDeliveries() {
    if (!deliveryCount) return;
    HostDelivery &d = deliveries[deliveryHead];
    uint8_t frame[225];
    if (d.usb && d.usbOffset < d.length) {
        const uint16_t count = deliveryFrame(d, frame, d.usbOffset, d.usbSeq, 220);
        bool written = Serial && writeUsbDelivery(Serial, frame, count + 5);
#if USB_PROTOCOL_ENABLED && defined(ARDUINO_ARCH_ESP32) && !ARDUINO_USB_CDC_ON_BOOT
        if (Qp1ngUsbSerial) written = writeUsbDelivery(Qp1ngUsbSerial, frame, count + 5) || written;
#endif
        if (written) { d.usbOffset += count; ++d.usbSeq; d.usbWait.progress(); }
        else if (d.usbWait.expired(millis())) {
            // A stopped USB reader must not retain both delivery slots or delay BLE/RF.
            d.usb = false; ++statUsbOutputDrops;
        }
    }
    if (d.ble && !deviceConnected) d.ble = false;
    if (d.ble && d.bleOffset < d.length && qp1ng::due(millis(), d.nextBle)) {
        const uint16_t maximum = min(uint16_t(220), uint16_t(max(uint16_t(23), uint16_t(peerMtu)) - 8));
        const uint16_t count = deliveryFrame(d, frame, d.bleOffset, d.bleSeq++, maximum);
        pTxCharacteristic->setValue(frame, count + 5); pTxCharacteristic->notify();
        d.bleOffset += count; d.nextBle = millis() + 25;
        if (d.bleOffset == d.length) ++statBleTxFrames;
    }
    if ((!d.usb || d.usbOffset == d.length) && (!d.ble || d.bleOffset == d.length)) {
        memset(d.bytes, 0, d.length); d.length = 0;
        deliveryHead = (deliveryHead + 1) % 2; --deliveryCount;
    }
}

class MySecurity : public BLESecurityCallbacks {
    uint32_t onPassKeyRequest() override { return sessionPin; }
    void onPassKeyNotify(uint32_t value) override { pendingPasskey = value; }
    bool onConfirmPIN(uint32_t) override { return false; } // Display-only passkey entry, no blind numeric confirmation.
    bool onSecurityRequest() override { return true; }
    void onAuthenticationComplete(esp_ble_auth_cmpl_t result) override {
        deviceConnected = result.success;
        // Standard GATT cache invalidation after firmware upgrades, retaining bonds.
#if defined(CONFIG_BT_GATTS_SEND_SERVICE_CHANGE_MANUAL)
        if (result.success && radioGattIf != ESP_GATT_IF_NONE) esp_ble_gatts_send_service_change_indication(radioGattIf, result.bd_addr);
#endif
    }
};
class MyServerCallbacks : public BLEServerCallbacks {
    void onConnect(BLEServer*, esp_ble_gatts_cb_param_t* param) override {
        bleLinkConnected = true; deviceConnected = false; peerMtu = 23;
        esp_ble_set_encryption(param->connect.remote_bda, ESP_BLE_SEC_ENCRYPT_MITM);
    }
    void onDisconnect(BLEServer*) override {
        bleLinkConnected = false; deviceConnected = false; peerMtu = 23; bleDisconnected = true;
    }
    void onMtuChanged(BLEServer*, esp_ble_gatts_cb_param_t* param) override { peerMtu = param->mtu.mtu; }
};
class MyCallbacks : public BLECharacteristicCallbacks {
    void onWrite(BLECharacteristic* characteristic) override {
        if (!deviceConnected || !bleQueue) return;
        const std::string value = characteristic->getValue();
        if (value.size() < 6 || value.size() > 260) { bleOverflow = true; return; }
        BleInput input{}; input.size = uint16_t(value.size()); memcpy(input.bytes, value.data(), input.size);
        if (xQueueSend(bleQueue, &input, 0) != pdTRUE) bleOverflow = true;
    }
};

class StatusCallbacks : public BLECharacteristicCallbacks {
    void onRead(BLECharacteristic* characteristic) override {
        uint8_t value[16];
        portENTER_CRITICAL(&statusMux);
        memcpy(value, radioStatusValue, sizeof(value));
        portEXIT_CRITICAL(&statusMux);
        characteristic->setValue(value, sizeof(value));
    }
};

bool ingestHostFrame(uint8_t* data, int length, const char* source) {
    if (!radioReady || inTxFragMode || !localModeAllowsTx()) return false;
    const auto result = hostAssembler.accept(data, length, source[0] == 'U' ? 1 : 2, millis());
    if (result == qp1ng::Result::Rejected) return false;
    if (result != qp1ng::Result::Complete) return true;
    // Each host keeps its own requested level: another host's command must not
    // change the power of a packet already being assembled for this one.
    if (!setRadioPower(hostTxPower[source[0] == 'U' ? 1 : 2])) {
        hostAssembler.reset(); powerResult = 4; updateRadioStatus(); return false;
    }
    expectedTotalLen = hostAssembler.total;
    memcpy(loraTxBuffer, hostAssembler.buffer, expectedTotalLen); hostAssembler.reset();
    txTotalChunks = (expectedTotalLen + 219) / 220; txCurrentChunk = 0;
    txCurrentHops = localHopBudget(txTotalChunks > 16 ? 0 : (txTotalChunks > 2 ? 1 : MAX_HOPS));
    currentTxHash = calculateHash(loraTxBuffer, expectedTotalLen);
    currentTxIsHost = true; currentTxIsRelay = false;
    relayEvidence.reset(); radioAccess.begin(millis(), txTotalChunks);
    lastHostHash = currentTxHash; lastHostLength = expectedTotalLen;
    lastTxBytes = expectedTotalLen; lastTxChunks = txTotalChunks;
    networkPressure = min(50.0f, networkPressure + float(expectedTotalLen) / 100.0f);
    inTxFragMode = true; lastTxState = "queued"; nextTxTime = millis() + qp1ng::RadioAccess::initialDelay(esp_random());
    updateRadioStatus();
    if (source[0] == 'B') ++statBleRxFrames;
    return true;
}
void serviceBleInput() {
    if (bleDisconnected) {
        bleDisconnected = false;
        if (hostAssembler.source == 2) hostAssembler.reset();
        xQueueReset(bleQueue); BLEDevice::startAdvertising();
    }
    if (bleOverflow) {
        bleOverflow = false;
        if (hostAssembler.source == 2) hostAssembler.reset();
        xQueueReset(bleQueue); consoleLog("BLE INPUT REJECTED", CP_RED);
    }
    if (pendingPasskey) {
        sessionPin = pendingPasskey;
        pendingPasskey = 0; consoleLog("PAIRING: OPEN SETUP > PHONE PIN", CP_GREEN);
    }
    BleInput input{};
    for (int i = 0; i < 4 && xQueueReceive(bleQueue, &input, 0) == pdTRUE; ++i) {
        uint16_t token = 0;
        if (qp1ng::parseStatusRequest(input.bytes, input.size, token)) {
            // Uses the original notify handle, including on bonded clients whose
            // GATT cache predates the optional status characteristic. Fits MTU 23.
            uint8_t reply[20] = {'Q', 'S', uint8_t(token >> 8), uint8_t(token)};
            updateRadioStatus();
            portENTER_CRITICAL(&statusMux);
            memcpy(reply + 4, radioStatusValue, sizeof(radioStatusValue));
            portEXIT_CRITICAL(&statusMux);
            if (deviceConnected) { pTxCharacteristic->setValue(reply, sizeof(reply)); pTxCharacteristic->notify(); }
        } else if (input.size >= 8 && memcmp(input.bytes, "TX_POWER", 8) == 0) {
            applyPowerCommand(reinterpret_cast<const char*>(input.bytes), input.size, 2);
        } else if (!ingestHostFrame(input.bytes, input.size, "BLE")) consoleLog("BLE FRAME REJECTED", CP_RED);
        memset(input.bytes, 0, input.size);
    }
}

// =========================================================================
// HARDWARE INIT & BOOT
// =========================================================================
#include "TDeckExperience.h"
void initHardware() {
    for(int i=0; i<MAX_RX_SESSIONS; i++) resetRxSession(i); 
    
    pinMode(BOARD_POWERON, OUTPUT); digitalWrite(BOARD_POWERON, HIGH);
    pinMode(BOARD_SDCARD_CS, OUTPUT); pinMode(RADIO_CS_PIN, OUTPUT); pinMode(BOARD_TFT_CS, OUTPUT);
    digitalWrite(BOARD_SDCARD_CS, HIGH); digitalWrite(RADIO_CS_PIN, HIGH); digitalWrite(BOARD_TFT_CS, HIGH);
    pinMode(BOARD_BAT_ADC, INPUT);
    pinMode(TRACKBALL_UP, INPUT_PULLUP); pinMode(TRACKBALL_DOWN, INPUT_PULLUP);
    pinMode(TRACKBALL_LEFT, INPUT_PULLUP); pinMode(TRACKBALL_RIGHT, INPUT_PULLUP);
    pinMode(TRACKBALL_CLICK, INPUT_PULLUP);
    SPI.begin(BOARD_SPI_SCK, BOARD_SPI_MISO, BOARD_SPI_MOSI);
    Wire.begin(BOARD_I2C_SDA, BOARD_I2C_SCL);
}

void setup() {
    bleQueue = xQueueCreateStatic(16, sizeof(BleInput), bleQueueStorage, &bleQueueControl);
    serialCommandBuffer.reserve(USB_COMMAND_MAX_LEN);
#if defined(ARDUINO_ARCH_ESP32) && ARDUINO_USB_CDC_ON_BOOT && ARDUINO_USB_MODE
    Serial.setRxBufferSize(2048);
    Serial.setTxBufferSize(2048);
    Serial.setTxTimeoutMs(0); // Capacity is checked first; never stall radio/UI on a stopped PC.
#endif
    Serial.begin(115200);
#if USB_PROTOCOL_ENABLED && defined(ARDUINO_ARCH_ESP32) && !ARDUINO_USB_CDC_ON_BOOT
    Qp1ngUsbSerial.begin(115200);
    USB.begin();
#endif
    chipMac = ESP.getEfuseMac(); 
    delay(250);
    serialDebugLog("USB_LOG_READY");
    memset(seenHashes, 0, sizeof(seenHashes)); 

    initHardware();
    pinMode(BOARD_TFT_BACKLIGHT, OUTPUT); digitalWrite(BOARD_TFT_BACKLIGHT, HIGH); 
    tft.init(); tft.setRotation(1); 
    deck::init();

    uint32_t analogNoise = analogRead(4) * analogRead(5);
    uint32_t foldedMac = (uint32_t)(chipMac >> 32) ^ (uint32_t)chipMac;
    uint32_t entropyPool = esp_random() ^ foldedMac ^ micros() ^ analogNoise;
    sessionPin = (entropyPool % 900000) + 100000;

    consoleLog("INIT RADIO (433MHz)...", CP_AMBER);
    int state = radio.begin(433.0);
    if (state == RADIOLIB_ERR_NONE) state = radio.setBandwidth(250.0);
    if (state == RADIOLIB_ERR_NONE) state = radio.setSpreadingFactor(9);
    if (state == RADIOLIB_ERR_NONE) state = radio.setCodingRate(5);
    // v15.4 passed 0x1214 into an 8-bit API (truncated to 0x14). Keep the actual
    // on-air value, explicitly, so deployed T-Deck peers remain compatible.
    if (state == RADIOLIB_ERR_NONE) state = radio.setSyncWord(uint8_t(0x14));
    radio.setDio1Action(setFlag);
    if (state == RADIOLIB_ERR_NONE) state = radio.startReceive(RADIOLIB_SX126X_RX_TIMEOUT_INF,
        RADIOLIB_IRQ_RX_DEFAULT_FLAGS | (1UL << RADIOLIB_IRQ_PREAMBLE_DETECTED));
    radioReady = state == RADIOLIB_ERR_NONE;
    if (radioReady) maxFrameMs = (radio.getTimeOnAir(228) + 999u) / 1000u;
    radioRecoveryAttempts = radioReady ? 0 : 3; // Failed initialization needs an explicit restart.
    consoleLog(radioReady ? "RADIO READY" : "RADIO INIT FAILED", radioReady ? CP_GREEN : CP_RED);

    char bleName[32];
    sprintf(bleName, "QP1NG_%04X", (uint16_t)(chipMac >> 32));
    BLEDevice::init(bleName);
    BLEDevice::setMTU(247); 
    BLEDevice::setEncryptionLevel(ESP_BLE_SEC_ENCRYPT_MITM);
    BLEDevice::setSecurityCallbacks(new MySecurity());
    BLEDevice::setCustomGattsHandler(observeGattRegistration);
    pServer = BLEDevice::createServer();
    pServer->setCallbacks(new MyServerCallbacks());
    BLEService *pService = pServer->createService(SERVICE_UUID);
    pTxCharacteristic = pService->createCharacteristic(CHARACTERISTIC_UUID_TX, BLECharacteristic::PROPERTY_NOTIFY);
    pTxCharacteristic->addDescriptor(new BLE2902());
    BLECharacteristic *pRxCharacteristic = pService->createCharacteristic(
        CHARACTERISTIC_UUID_RX, 
        BLECharacteristic::PROPERTY_WRITE | BLECharacteristic::PROPERTY_WRITE_NR
    );
    pRxCharacteristic->setAccessPermissions(ESP_GATT_PERM_WRITE_ENC_MITM);
    pRxCharacteristic->setCallbacks(new MyCallbacks());
    pStatusCharacteristic = pService->createCharacteristic("6E400004-B5A3-F393-E0A9-E50E24DCCA9E", BLECharacteristic::PROPERTY_READ);
    pStatusCharacteristic->setAccessPermissions(ESP_GATT_PERM_READ_ENC_MITM);
    pStatusCharacteristic->setCallbacks(new StatusCallbacks());
    updateRadioStatus();
    pService->start();
    BLESecurity *pSecurity = new BLESecurity();
    pSecurity->setStaticPIN(sessionPin);
    pSecurity->setAuthenticationMode(ESP_LE_AUTH_REQ_SC_MITM_BOND);
    pSecurity->setCapability(ESP_IO_CAP_OUT);
    pSecurity->setInitEncryptionKey(ESP_BLE_ENC_KEY_MASK | ESP_BLE_ID_KEY_MASK);
    pServer->getAdvertising()->start();
    
    consoleLog("PAIR PIN IN SETUP > PHONE PAIRING", CP_GREEN);
}

// =========================================================================
// ECOLOGICAL ASYNC LOOP
// =========================================================================
bool resumeRadioReceive() {
    radioActionDone = false; channelScanActive = false; receiveGuard.reset();
    radioReady = radio.startReceive(RADIOLIB_SX126X_RX_TIMEOUT_INF,
        RADIOLIB_IRQ_RX_DEFAULT_FLAGS | (1UL << RADIOLIB_IRQ_PREAMBLE_DETECTED)) == RADIOLIB_ERR_NONE;
    if (radioReady) radioRecoveryAttempts = 0;
    else { ++statRadioErrors; ++radioRecoveryAttempts; radioRecoveryAt = millis() + 1000; }
    updateRadioStatus();
    return radioReady;
}

void finishRadioTx(bool success) {
    if (isTransmitting) statTxAirtimeMs += millis() - txStartedAt;
    radio.finishTransmit(); isTransmitting = false; inTxFragMode = false;
    channelScanActive = false; radioAccess.reset(); relayEvidence.reset();
    notifyLocalTx(success);
    if (currentTxIsHost) lastTxState = success ? "sent" : "error";
    if (success) { ++statRfTxSequences; markHashSeen(currentTxHash); }
    memset(loraTxBuffer, 0, expectedTotalLen);
    consoleLog(success ? "RADIO TX COMPLETE" : "RADIO TX FAILED", success ? CP_GREEN : CP_RED);
    currentTxIsHost = currentTxIsRelay = false;
    resumeRadioReceive();
    updateRadioStatus();
}
void receiveRadioPacket() {
    uint8_t frame[256]; const size_t length = radio.getPacketLength();
    if (length < 9 || length > 228) { resumeRadioReceive(); return; }
    const int state = radio.readData(frame, length);
    const float rssi = radio.getRSSI(), snr = radio.getSNR();
    deck::lastRssi = rssi; deck::lastSnr = snr;
    // Restore reception before UI or delivery work, so the next packet can arrive.
    resumeRadioReceive();
    if (state != RADIOLIB_ERR_NONE || frame[0] != 0x55) return;
    uint32_t id = uint32_t(frame[2]) | uint32_t(frame[3]) << 8 | uint32_t(frame[4]) << 16 | uint32_t(frame[5]) << 24;
    if (inTxFragMode && currentTxIsRelay && !isTransmitting && txCurrentChunk == 0 &&
        relayEvidence.observe(frame, length, loraTxBuffer, expectedTotalLen, currentTxHash, txCurrentHops)) {
        // Never cancel a phone/local message or an already started relay.
        inTxFragMode = false; currentTxIsRelay = false; radioAccess.reset(); relayEvidence.reset();
        memset(loraTxBuffer, 0, expectedTotalLen); ++statRelayCancelled;
        consoleLog("REDUNDANT RELAY SKIPPED", CP_BLUE); updateRadioStatus();
    }
    if (isHashSeen(id) || (inTxFragMode && currentTxHash == id)) return;
    const int slot = getRxSession(id); if (slot < 0) return;
    auto &ses = rxSessions[slot];
    const auto result = ses.accept(frame, length, millis());
    if (result != qp1ng::Result::Rejected)
        radioAccess.receivedFragment(millis(), frame[6], frame[7], esp_random());
    if (result != qp1ng::Result::Complete) return;
    // If host output is congested leave this hash eligible for a later peer retry.
    const bool roomPacket = deck::Room::recognizes(ses.buffer, ses.assembledLen);
    if (roomPacket) handleRoomPacket(ses.buffer, ses.assembledLen);
    else if (!enqueueDelivery(ses.buffer, ses.assembledLen)) { resetRxSession(slot); return; }
    markHashSeen(id); ++statRfRxSequences; statRfChunksRx += ses.totalChunks;
    lastRxBytes = ses.assembledLen; lastRxChunks = ses.totalChunks;
    consoleLog("RADIO RX ASSEMBLED", CP_GREEN);
    // Keep legacy relay policy and hop budget; never overwrite a locally queued TX.
    if (localRelayEnabled() && ses.hops && !inTxFragMode && hostAssembler.total == 0) {
        memcpy(loraTxBuffer, ses.buffer, ses.assembledLen); expectedTotalLen = ses.assembledLen;
        txTotalChunks = ses.totalChunks; txCurrentChunk = 0; txCurrentHops = ses.hops - 1;
        currentTxHash = id; inTxFragMode = true; currentTxIsHost = false; currentTxIsRelay = true;
        relayEvidence.reset(); radioAccess.begin(millis(), txTotalChunks);
        nextTxTime = millis() + calculateAdaptiveDelay(rssi, snr, id); ++statRelayQueued;
        updateRadioStatus();
    }
    resetRxSession(slot);
}

void deferRadioTx() {
    ++statChannelDeferrals;
    nextTxTime = millis() + radioAccess.backoff(esp_random());
}

void startQueuedTransmit() {
    channelScanActive = false; radioActionDone = false;
    isTransmitting = true; txStartedAt = millis();
    const uint16_t offset = txCurrentChunk * 220;
    const uint16_t count = min(uint16_t(220), uint16_t(expectedTotalLen - offset));
    if (radio.startTransmit(meshTxBuffer, count + 8) != RADIOLIB_ERR_NONE) {
        ++statRadioErrors; finishRadioTx(false);
    }
}

void serviceRadioAccess() {
    if (!inTxFragMode || isTransmitting) return;
    if (radioAccess.expired(millis())) { consoleLog("CHANNEL WAIT TIMED OUT", CP_AMBER); finishRadioTx(false); return; }
    if (!radioReady) return;
    if (channelScanActive) {
        if (qp1ng::elapsed(millis(), channelScanStarted, 150)) { ++statRadioErrors; finishRadioTx(false); }
        return;
    }
    if (radioAccess.receivingBurst(millis())) return;
    if (radioActionDone || !qp1ng::due(millis(), nextTxTime)) return;
#if QP1NG_TEST_HOOKS
    if (testChannelBusy) {
        if (!qp1ng::due(millis(), testBusyUntil)) { deferRadioTx(); return; }
        testChannelBusy = false;
    }
#endif
    const uint32_t irq = radio.getIrqFlags();
    if (irq & RADIOLIB_SX126X_IRQ_RX_DONE) { radioActionDone = true; return; }
    const auto action = receiveGuard.observe(millis(), irq & RADIOLIB_SX126X_IRQ_PREAMBLE_DETECTED,
        irq & RADIOLIB_SX126X_IRQ_HEADER_VALID, maxFrameMs);
    if (action == qp1ng::ReceiveGuard::Action::Hold) { deferRadioTx(); return; }
    if (action == qp1ng::ReceiveGuard::Action::RestartReceive) { resumeRadioReceive(); deferRadioTx(); return; }
    if (action == qp1ng::ReceiveGuard::Action::ClearPreamble)
        radio.clearIrqFlags(RADIOLIB_SX126X_IRQ_PREAMBLE_DETECTED);
    // Prepare before CAD so a clear result can immediately start TX.
    const uint16_t offset = txCurrentChunk * 220;
    const uint16_t count = min(uint16_t(220), uint16_t(expectedTotalLen - offset));
    meshTxBuffer[0] = 0x55; meshTxBuffer[1] = txCurrentHops;
    for (int i = 0; i < 4; ++i) meshTxBuffer[2 + i] = currentTxHash >> (i * 8);
    meshTxBuffer[6] = txCurrentChunk; meshTxBuffer[7] = txTotalChunks;
    memcpy(meshTxBuffer + 8, loraTxBuffer + offset, count);
    if (radioActionDone) return;
    channelScanActive = true; channelScanStarted = millis(); ++statChannelScans;
    if (radio.startChannelScan() != RADIOLIB_ERR_NONE) { ++statRadioErrors; finishRadioTx(false); }
}

void loop() {
    // Radio/SPI/display operations have one owner: callbacks only enqueue bounded data.
    if (radioReady && radioActionDone) {
        radioActionDone = false;
        if (channelScanActive) {
#if QP1NG_TEST_HOOKS
            if (testLoseCadIrq) { testLoseCadIrq = false; }
            else
#endif
            {
            const int state = radio.getChannelScanResult();
            if (state == RADIOLIB_CHANNEL_FREE) startQueuedTransmit();
            else if (state == RADIOLIB_LORA_DETECTED) { resumeRadioReceive(); deferRadioTx(); }
            else { ++statRadioErrors; finishRadioTx(false); }
            }
        } else if (isTransmitting) {
            statTxAirtimeMs += millis() - txStartedAt; radioAccess.progressed();
            isTransmitting = false; ++txCurrentChunk;
            if (txCurrentChunk == txTotalChunks) finishRadioTx(true);
            else { radio.finishTransmit(); resumeRadioReceive(); nextTxTime = millis() + 80 + esp_random() % 80 + uint32_t(networkPressure * 10); }
        } else receiveRadioPacket();
    }
    if (isTransmitting && qp1ng::elapsed(millis(), txStartedAt, 4000)) { ++statRadioErrors; finishRadioTx(false); }
    if (!radioReady && radioRecoveryAttempts < 3 && qp1ng::due(millis(), radioRecoveryAt)) resumeRadioReceive();
    serviceRadioAccess();
    serviceBleInput(); processUsbCommands(); serviceDeliveries(); serviceExperience();
    if (hostAssembler.total && qp1ng::elapsed(millis(), hostAssembler.updated, qp1ng::HostTimeout)) hostAssembler.reset();
    for (int i = 0; i < MAX_RX_SESSIONS; ++i) {
        if (rxSessions[i].active && qp1ng::elapsed(millis(), rxSessions[i].lastUpdate, RX_CHUNK_TIMEOUT_MS)) resetRxSession(i);
    }
    if (qp1ng::elapsed(millis(), lastPressureUpdate, 1000)) {
        lastPressureUpdate = millis(); networkPressure *= 0.95f;

    }
    // Keep idle yielding, but avoid adding 15 x 5 ms to every display frame.
    // Radio IRQ work still runs first on every loop between the 16-row stripes.
    delay(deck::flushRow < 240 ? 1 : 5);
}
