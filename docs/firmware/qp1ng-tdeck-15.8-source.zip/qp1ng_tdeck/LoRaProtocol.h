#pragma once
#include <stdint.h>
#include <stddef.h>
#include <string.h>

namespace qp1ng {
constexpr size_t Chunk = 220;
constexpr size_t MaxChunks = 32;
constexpr size_t MaxPayload = Chunk * MaxChunks;
constexpr uint32_t HostTimeout = 15000;
constexpr uint32_t RadioTimeout = 60000;
constexpr int8_t MinTxPower = -9, MaxTxPower = 22, DefaultTxPower = 10;
inline bool parseTxPower(const char* text, size_t length, int8_t& power) {
    if (length < 10 || length > 12 || memcmp(text, "TX_POWER=", 9) != 0) return false;
    size_t i = 9; bool negative = text[i] == '-';
    if (negative && ++i == length) return false;
    int value = 0;
    for (; i < length; ++i) {
        if (text[i] < '0' || text[i] > '9') return false;
        value = value * 10 + text[i] - '0';
    }
    if (negative) value = -value;
    if (value < MinTxPower || value > MaxTxPower) return false;
    power = int8_t(value); return true;
}
enum class Result { Rejected, More, Complete };
inline bool parseStatusRequest(const uint8_t* data, size_t length, uint16_t& token) {
    if (length != 17 || memcmp(data, "QP1NG_STATUS=", 13) != 0) return false;
    uint16_t value = 0;
    for (size_t i = 13; i < 17; ++i) {
        const uint8_t c = data[i];
        int digit = c >= '0' && c <= '9' ? c - '0' : (c >= 'a' && c <= 'f' ? c - 'a' + 10 :
            (c >= 'A' && c <= 'F' ? c - 'A' + 10 : -1));
        if (digit < 0) return false;
        value = uint16_t((value << 4) | digit);
    }
    token = value; return true;
}
inline bool elapsed(uint32_t now, uint32_t since, uint32_t duration) { return uint32_t(now - since) >= duration; }
inline bool due(uint32_t now, uint32_t deadline) { return int32_t(now - deadline) >= 0; }
inline uint32_t hash(const uint8_t* data, size_t length) {
    uint32_t value = 2166136261u;
    for (size_t i = 0; i < length; ++i) { value ^= data[i]; value *= 16777619u; }
    return value; // Legacy corruption/deduplication check; not cryptographic authentication.
}

struct HostAssembler {
    uint8_t buffer[MaxPayload]{};
    uint16_t total = 0, offset = 0, sequence = 0;
    uint8_t source = 0;
    uint32_t updated = 0;
    void reset() { memset(buffer, 0, offset); total = offset = sequence = 0; source = 0; updated = 0; }
    Result reject() { reset(); return Result::Rejected; }
    Result accept(const uint8_t* frame, size_t length, uint8_t channel, uint32_t now) {
        if (total && elapsed(now, updated, HostTimeout)) reset();
        // A second host cannot clobber a packet already being assembled by the first one.
        if (total && channel != source) return Result::Rejected;
        if (length < 6 || length > 260) return reject();
        const uint16_t size = uint16_t(frame[0]) << 8 | frame[1];
        const uint16_t seq = uint16_t(frame[2]) << 8 | frame[3];
        const uint8_t flags = frame[4];
        if (!size || size > MaxPayload || (flags & 0xFC)) return reject();
        if (flags & 1) {
            reset();
            if (seq) return Result::Rejected;
            total = size; source = channel;
        }
        const size_t next = offset + length - 5;
        if (!total || total != size || sequence != seq || next > total ||
            bool(flags & 2) != (next == total)) return reject();
        memcpy(buffer + offset, frame + 5, length - 5);
        offset = uint16_t(next); ++sequence; updated = now;
        return (flags & 2) ? Result::Complete : Result::More;
    }
};

struct RadioAssembly {
    bool active = false;
    uint32_t hash = 0, lastUpdate = 0;
    uint8_t totalChunks = 0, chunksReceived = 0, hops = 0;
    bool chunkMap[MaxChunks]{};
    uint16_t assembledLen = 0;
    uint8_t buffer[MaxPayload]{};
    void reset() {
        memset(buffer, 0, sizeof(buffer)); memset(chunkMap, 0, sizeof(chunkMap));
        active = false; hash = lastUpdate = 0; totalChunks = chunksReceived = hops = 0; assembledLen = 0;
    }
    Result accept(const uint8_t* frame, size_t length, uint32_t now) {
        if (length < 9 || length > 8 + Chunk || frame[0] != 0x55 || frame[1] > 3) return Result::Rejected;
        const uint32_t id = uint32_t(frame[2]) | uint32_t(frame[3]) << 8 | uint32_t(frame[4]) << 16 | uint32_t(frame[5]) << 24;
        const uint8_t index = frame[6], count = frame[7];
        const size_t bytes = length - 8;
        if (!count || count > MaxChunks || index >= count || (index + 1 < count && bytes != Chunk)) return Result::Rejected;
        if (active && elapsed(now, lastUpdate, RadioTimeout)) reset();
        if (!active) { active = true; hash = id; totalChunks = count; hops = frame[1]; }
        // Keep the first metadata; packets from a different route may have a lower hop budget.
        if (hash != id || totalChunks != count) return Result::Rejected;
        if (frame[1] < hops) hops = frame[1];
        const size_t offset = index * Chunk;
        if (chunkMap[index]) {
            if (memcmp(buffer + offset, frame + 8, bytes) != 0 ||
                (index + 1 == count && assembledLen != offset + bytes)) { reset(); return Result::Rejected; }
            return Result::More;
        }
        memcpy(buffer + offset, frame + 8, bytes);
        chunkMap[index] = true; ++chunksReceived; lastUpdate = now;
        if (index + 1 == count) assembledLen = uint16_t(offset + bytes);
        if (chunksReceived != totalChunks) return Result::More;
        if (!assembledLen || qp1ng::hash(buffer, assembledLen) != hash) { reset(); return Result::Rejected; }
        return Result::Complete;
    }
};
} // namespace qp1ng
