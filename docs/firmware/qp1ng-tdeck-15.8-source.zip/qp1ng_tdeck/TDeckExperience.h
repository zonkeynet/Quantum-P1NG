#pragma once
#include "TDeckRoom.h"
#include <esp_partition.h>

#ifndef QP1NG_TEST_HOOKS
#define QP1NG_TEST_HOOKS 0
#endif

namespace deck {
TFT_eSprite canvas(&tft);
Room room;
Editor<TextLimit> draft;
Editor<32> codeEditor;
Page page = Page::Status;
Mode mode = Mode::Mesh;
uint8_t setting = 0, helpPage = 0, brightness = 12, sensitivity = 1;
uint32_t dimAfter = 60000, lastInteraction = 0, lastPaint = 0, lastMetrics = 0;
uint32_t keyCount = 0, ballCount = 0, clickCount = 0, lastKeyPoll = 0;
bool dirty = true, keyboardOnline = false, dimmed = false, generatedCode = false;
bool roomStorageSafe = false;
bool tabsFocused = true;
uint32_t frameStarted = 0, frameMs = 0, lastInputAt = 0, maxInputGap = 0;
int flushRow = 240;
int batteryPercent = 0;
float lastRssi = 0, lastSnr = 0;
char notice[49] = "Ready. TAB changes page.";
uint32_t noticeUntil = 0;
struct Event { char text[43]{}; uint16_t color = CP_BLUE; } events[6];
uint8_t eventNext = 0, eventCount = 0;
struct Message { char text[TextLimit + 1]{}; uint32_t peer = 0; bool mine = false; } messages[6];
uint8_t messageNext = 0, messageCount = 0, messageBack = 0;
struct Pending {
    uint8_t plain[TextLimit]{};
    uint16_t length = 0;
    uint32_t sequence = 0, next = 0, started = 0;
    uint8_t attempts = 0;
    bool active = false, received = false;
    void clear() { wipe(plain, sizeof(plain)); length = 0; sequence = next = started = 0; attempts = 0; active = received = false; }
} pending;
struct Ack { uint64_t peer = 0; uint32_t sequence = 0, due = 0; } acks[4];
uint8_t ackCount = 0;
bool localTx = false;
uint32_t localSequence = 0;
const char* deliveryLabel = "No message sent";
volatile uint16_t ballEdges[4]{};
portMUX_TYPE ballMux = portMUX_INITIALIZER_UNLOCKED;
const uint8_t ballPins[4] = {TRACKBALL_UP, TRACKBALL_DOWN, TRACKBALL_LEFT, TRACKBALL_RIGHT};
uint8_t ballIndex[4] = {0, 1, 2, 3};
TrackballMotion ballMotion;
uint32_t ballDirections[4]{};

void IRAM_ATTR ballEdge(void* arg) {
    const uint8_t i = *static_cast<uint8_t*>(arg);
    portENTER_CRITICAL_ISR(&ballMux);
    if (ballEdges[i] < 64) ++ballEdges[i];
    portEXIT_CRITICAL_ISR(&ballMux);
}

void inform(const char* text) {
    snprintf(notice, sizeof(notice), "%s", text);
    noticeUntil = millis() + 4500; dirty = true;
}
void event(const char* text, uint16_t color) {
    auto &e = events[eventNext]; snprintf(e.text, sizeof(e.text), "%s", text); e.color = color;
    eventNext = (eventNext + 1) % 6; if (eventCount < 6) ++eventCount; dirty = true;
}
bool idle() { return !inTxFragMode && !isTransmitting && !radioActionDone && hostAssembler.total == 0; }

void backlight(uint8_t value) {
    // T-Deck uses a pulse-controlled 16-step backlight driver, not PWM.
    static int level = -1;
    value = constrain(value, 1, 16);
    if (level < 0) {
        digitalWrite(BOARD_TFT_BACKLIGHT, LOW); delay(3);
        digitalWrite(BOARD_TFT_BACKLIGHT, HIGH); delayMicroseconds(30); level = 16;
    }
    const int pulses = (level - value + 16) % 16;
    for (int i = 0; i < pulses; ++i) {
        digitalWrite(BOARD_TFT_BACKLIGHT, LOW); delayMicroseconds(2);
        digitalWrite(BOARD_TFT_BACKLIGHT, HIGH); delayMicroseconds(2);
    }
    level = value;
}
void wake() { lastInteraction = millis(); if (dimmed) { dimmed = false; backlight(brightness); dirty = true; } }
void clearSession() {
    room.clear(); draft.clear(); codeEditor.clear(); pending.clear();
    wipe(messages, sizeof(messages)); messageNext = messageCount = messageBack = 0;
    wipe(acks, sizeof(acks)); ackCount = 0;
    generatedCode = false; deliveryLabel = "No message sent";
}
void addMessage(const char* text, uint64_t peer, bool mine) {
    auto &m = messages[messageNext]; wipe(&m, sizeof(m));
    snprintf(m.text, sizeof(m.text), "%s", text); m.peer = uint32_t(peer); m.mine = mine;
    messageNext = (messageNext + 1) % 6; if (messageCount < 6) ++messageCount;
    messageBack = 0; dirty = true;
}
bool queueRadio(const uint8_t* bytes, size_t length, uint32_t seq) {
    if (!radioReady || !idle() || mode == Mode::Listen || length == 0 || length > 220) return false;
    if (!setRadioPower(hostTxPower[0])) return false;
    memcpy(loraTxBuffer, bytes, length); expectedTotalLen = uint16_t(length);
    txTotalChunks = 1; txCurrentChunk = 0; txCurrentHops = mode == Mode::Mesh ? MAX_HOPS : 0;
    currentTxHash = qp1ng::hash(bytes, length); currentTxIsHost = false;
    localTx = true; localSequence = seq; lastTxBytes = uint16_t(length); lastTxChunks = 1;
    networkPressure = min(50.0f, networkPressure + float(length) / 100.0f);
    inTxFragMode = true; nextTxTime = millis() + 20; updateRadioStatus(); dirty = true;
    return true;
}
void serviceChat() {
    if (pending.active && qp1ng::elapsed(millis(), pending.started, 60000)) {
        pending.clear(); deliveryLabel = "Timed out. Delivery unknown."; inform(deliveryLabel);
    }
    if (!room.ready || !radioReady || !idle() || mode == Mode::Listen) return;
    uint8_t packet[Room::MaxPacket]{};
    if (ackCount && qp1ng::due(millis(), acks[0].due)) {
        uint8_t body[12]; write64(body, acks[0].peer); write32(body + 8, acks[0].sequence);
        const size_t length = room.seal(2, body, sizeof(body), room.reserveSequence(), packet);
        if (length && queueRadio(packet, length, 0)) {
            for (int i = 1; i < ackCount; ++i) acks[i - 1] = acks[i];
            acks[--ackCount] = Ack{};
        }
        wipe(body, sizeof(body));
    } else if (pending.active && !pending.received && qp1ng::due(millis(), pending.next)) {
        if (pending.attempts >= 3) {
            pending.clear(); deliveryLabel = "No receipt. Delivery unknown."; inform(deliveryLabel);
        } else {
            const size_t length = room.seal(1, pending.plain, pending.length, pending.sequence, packet);
            if (!length) { pending.clear(); deliveryLabel = "Encryption failed. Nothing sent."; inform(deliveryLabel); }
            else if (queueRadio(packet, length, pending.sequence)) {
                ++pending.attempts; pending.next = millis() + 12000;
                deliveryLabel = "Transmitting..."; dirty = true;
            }
        }
    }
    wipe(packet, sizeof(packet));
}
void receive(const uint8_t* packet, size_t length) {
    uint8_t plain[TextLimit + 1]{}; ReplayResult replay = ReplayResult::Stale;
    if (!room.open(packet, length, plain, replay)) return;
    const uint64_t peer = read64(packet + 8);
    const uint32_t seq = read32(packet + 16);
    if (packet[4] == 1) {
        if (replay == ReplayResult::Fresh) {
            addMessage(reinterpret_cast<char*>(plain), peer, false); event("ROOM MESSAGE AUTHENTICATED", CP_GREEN);
        }
        bool queued = false;
        for (uint8_t i = 0; i < ackCount; ++i) if (acks[i].peer == peer && acks[i].sequence == seq) queued = true;
        // Duplicate, authenticated retries get another receipt, without redisplay.
        if (!queued && ackCount < 4 && mode != Mode::Listen) {
            auto &ack = acks[ackCount++]; ack.peer = peer; ack.sequence = seq;
            ack.due = millis() + 200 + esp_random() % 500;
        }
    } else if (pending.active && read64(plain) == room.sender && read32(plain + 8) == pending.sequence) {
        pending.clear(); deliveryLabel = "Received by a room member"; inform(deliveryLabel);
    }
    wipe(plain, sizeof(plain));
}

void go(Page target, bool focusTabs = false) {
    page = target; tabsFocused = focusTabs && uint8_t(target) < 5;
    ballMotion.clear(); dirty = true; wake();
}
void nextPage() {
    if (page == Page::Room) { codeEditor.clear(); generatedCode = false; go(Page::Settings); return; }
    if (uint8_t(page) > 4) { go(Page::Status, true); return; }
    go(Page((uint8_t(page) + 1) % 5), true);
}
void startSend() {
    if (!room.ready) { inform("Join a room in SETUP first."); return; }
    if (mode == Mode::Listen) { inform("LISTEN mode: transmission disabled."); return; }
    if (!radioReady) { inform("Radio unavailable. Draft kept."); return; }
    if (!draft.meaningful()) { inform("Type a message first."); return; }
    if (pending.active) { inform("Wait for receipt or timeout."); return; }
    go(Page::Send);
}
void changeSetting(int direction) {
    if (setting <= 1 && (!idle() || pending.active || activeRxSessions())) { inform("Radio busy. Try again shortly."); return; }
    if (setting == 0) {
        mode = Mode((int(mode) + (direction > 0 ? 1 : 2)) % 3);
        if (mode == Mode::Listen) { wipe(acks, sizeof(acks)); ackCount = 0; }
        event(modeName(mode), CP_BLUE);
    } else if (setting == 1) {
        const int power = constrain(int(hostTxPower[0]) + direction, int(qp1ng::MinTxPower), int(qp1ng::MaxTxPower));
        if (setRadioPower(int8_t(power))) hostTxPower[0] = int8_t(power);
        else inform("Radio power change failed.");
    } else if (setting == 2) { brightness = uint8_t(constrain(int(brightness) + direction, 1, 16)); backlight(brightness); }
    else if (setting == 3) { dimAfter = dimAfter == 60000 ? 15000 : (dimAfter == 15000 ? 0 : 60000); }
    else if (setting == 4) { sensitivity = uint8_t(constrain(int(sensitivity) + direction, 1, 6)); }
    dirty = true; updateRadioStatus();
}
void activate() {
    if (tabsFocused && uint8_t(page) < 5) { tabsFocused = false; dirty = true; wake(); return; }
    if (page == Page::Status) { go(Page::Chat); return; }
    if (page == Page::Chat) { startSend(); return; }
    if (page == Page::Send) {
        if (!room.ready || pending.active || mode == Mode::Listen || !radioReady) { go(Page::Chat); inform("Cannot send. Draft kept."); return; }
        const uint32_t seq = room.reserveSequence();
        if (!seq) { go(Page::Chat); inform("Create a new room session."); return; }
        pending.clear(); pending.sequence = seq; pending.length = uint16_t(draft.length);
        memcpy(pending.plain, draft.text, draft.length); pending.active = true; pending.started = pending.next = millis();
        addMessage(draft.text, room.sender, true); draft.clear(); deliveryLabel = "Queued. Waiting for radio.";
        go(Page::Chat); return;
    }
    if (page == Page::Forget) {
        if (!idle()) { inform("Wait for the current transmission."); return; }
        clearSession(); go(Page::Status); inform("Room, draft and history cleared."); return;
    }
    if (page == Page::Room) {
        if (!roomStorageSafe) { inform("Fresh install required for local chat."); return; }
        if (pending.active || !idle()) { inform("Radio busy. Room not changed."); return; }
        uint8_t code[16]{};
        if (!roomCode(codeEditor.text, codeEditor.length, code)) { inform("Enter all 32 hexadecimal characters."); return; }
        // Explicit new session; discard prior messages and pending receipts.
        clearSession(); const bool ok = room.join(code); wipe(code, sizeof(code));
        go(Page::Chat); inform(ok ? "Room ready. Code is no longer displayed." : "Room initialization failed."); return;
    }
    if (page == Page::Settings) {
        if ((setting == 5 || setting == 6) && !roomStorageSafe) {
            inform("Fresh install required for local chat."); return;
        }
        if (setting < 5) changeSetting(1);
        else if (setting == 5) { codeEditor.clear(); generatedCode = false; go(Page::Room); }
        else if (setting == 6) {
            uint8_t code[16]; esp_fill_random(code, sizeof(code)); codeEditor.clear();
            const char* digits = "0123456789ABCDEF";
            for (auto b : code) { codeEditor.insert(digits[b >> 4]); codeEditor.insert(digits[b & 15]); }
            wipe(code, sizeof(code)); generatedCode = true; go(Page::Room);
        } else if (setting == 7) go(Page::Pair);
        else if (setting == 8) go(Page::Forget);
    } else if (page == Page::Help) { helpPage = (helpPage + 1) % 3; dirty = true; }
    else go(Page::Status);
}
void key(uint8_t c) {
    if (!c) return;
    ++keyCount; wake(); dirty = true;
    if (c == 9) { nextPage(); return; }
    if (c == 27) {
        if (page == Page::Room) { codeEditor.clear(); generatedCode = false; }
        go(page == Page::Send ? Page::Chat : Page::Status, page != Page::Send); return;
    }
    if (c == 13 || c == 10) { activate(); return; }
    if (page != Page::Chat && page != Page::Room && c >= '1' && c <= '5') {
        go(Page(c - '1')); return;
    }
    tabsFocused = false;
    if (page == Page::Chat) {
        if (!roomStorageSafe) { inform("Fresh install required for local chat."); return; }
        if (c == 8 || c == 127) draft.backspace();
        else if (c >= 32 && c <= 126 && !draft.insert(c)) inform("Message full (172 characters).");
    } else if (page == Page::Room) {
        if (c == 8 || c == 127) { codeEditor.backspace(); generatedCode = false; }
        else if (hexDigit(char(c)) >= 0) { codeEditor.insert(uint8_t(toupper(c))); generatedCode = false; }
    } else if (page == Page::Settings) {
        c = uint8_t(tolower(c));
        if (c == 'w' || c == 'k') setting = (setting + 8) % 9;
        else if (c == 's' || c == 'j') setting = (setting + 1) % 9;
        else if (c == 'a' || c == 'h') changeSetting(-1);
        else if (c == 'd' || c == 'l') changeSetting(1);
    }
}
void navigate(int direction) {
    ++ballCount; ++ballDirections[direction]; wake(); dirty = true;
    if (tabsFocused && uint8_t(page) < 5) {
        if (direction >= 2) go(Page((uint8_t(page) + (direction == 2 ? 4 : 1)) % 5), true);
        else if (direction == 1) tabsFocused = false;
        return;
    }
    if (page == Page::Settings) {
        if (direction == 0) { if (setting) --setting; else tabsFocused = true; }
        else if (direction == 1) { if (setting < 8) ++setting; }
        else if (setting < 5) changeSetting(direction == 2 ? -1 : 1);
        else if (direction == 2) tabsFocused = true;
    } else if (page == Page::Chat) {
        if (direction == 0) { if (messageBack + 1 < messageCount) ++messageBack; else tabsFocused = true; }
        else if (direction == 1 && messageBack) --messageBack;
        else if (direction >= 2) {
            if (!draft.length) tabsFocused = true;
            else draft.move(direction == 2 ? -1 : 1);
        }
    } else if (page == Page::Room) { if (direction >= 2) codeEditor.move(direction == 2 ? -1 : 1); }
    else if (page == Page::Send || page == Page::Forget) go(Page::Chat);
    else if (page == Page::Help) {
        if (direction == 0 && helpPage == 0) tabsFocused = true;
        else helpPage = (helpPage + (direction == 0 || direction == 2 ? 2 : 1)) % 3;
    } else if (page == Page::Pair) go(Page::Settings);
    else if (uint8_t(page) <= 4) {
        tabsFocused = true;
        if (direction >= 2) go(Page((uint8_t(page) + (direction == 2 ? 4 : 1)) % 5), true);
    }
}
void input() {
    const uint32_t now = millis();
    if (lastInputAt && uint32_t(now - lastInputAt) > maxInputGap) maxInputGap = uint32_t(now - lastInputAt);
    lastInputAt = now;
    if (qp1ng::elapsed(now, lastKeyPoll, keyboardOnline ? 20 : 2000)) {
        lastKeyPoll = now;
        keyboardOnline = Wire.requestFrom(uint8_t(0x55), uint8_t(1)) == 1;
        if (keyboardOnline && Wire.available()) key(uint8_t(Wire.read()));
        while (Wire.available()) Wire.read();
    }
    static uint32_t lastBall = 0;
    const bool down = digitalRead(TRACKBALL_CLICK) == LOW;
    if (qp1ng::elapsed(now, lastBall, 20)) {
        lastBall = now;
        uint16_t counts[4];
        portENTER_CRITICAL(&ballMux);
        for (int i = 0; i < 4; ++i) { counts[i] = ballEdges[i]; ballEdges[i] = 0; }
        portEXIT_CRITICAL(&ballMux);
        // Rolling while clicking must not move the selection under the click.
        if (down) ballMotion.clear();
        else {
            const int direction = ballMotion.update(counts, now, sensitivity);
            if (direction >= 0) navigate(direction);
        }
    }
    static bool previous = false, stable = false, longDone = false;
    static uint32_t changed = 0, pressed = 0;
    if (down != previous) { previous = down; changed = now; }
    if (down != stable && qp1ng::elapsed(now, changed, 25)) {
        stable = down;
        if (down) { pressed = now; longDone = false; wake(); }
        else if (!longDone) { ++clickCount; activate(); }
    }
    if (stable && !longDone && qp1ng::elapsed(now, pressed, 650)) { longDone = true; ++clickCount; nextPage(); }
}

constexpr uint16_t Background = 0x0823, Surface = 0x1085, Stroke = 0x29AA, Muted = 0xA577, Pink = 0xF3B8;
void label(int x, int y, const char* text, uint16_t color = CP_WHITE, uint8_t font = 1) {
    canvas.setTextFont(font); canvas.setTextSize(1); canvas.setTextColor(color);
    canvas.setCursor(x, y); canvas.print(text);
}
void box(int x, int y, int w, int h, uint16_t accent = Stroke) {
    canvas.fillRoundRect(x, y, w, h, 7, Surface); canvas.drawRoundRect(x, y, w, h, 7, accent);
}
void wrapped(int x, int y, const char* text, size_t width, size_t lines, uint16_t color = CP_WHITE) {
    for (size_t i = 0; i < lines && *text; ++i) {
        char line[51]{}; const size_t count = min(min(strlen(text), width), size_t(50));
        memcpy(line, text, count); label(x, y + int(i) * 13, line, color); text += count;
    }
}
void glyph(int x, int y, uint8_t which, uint16_t color) {
    if (which == 0) { // radio node
        canvas.drawCircle(x + 6, y + 6, 5, color); canvas.fillCircle(x + 6, y + 6, 2, color);
        canvas.drawLine(x + 6, y + 11, x + 6, y + 16, color); canvas.drawFastHLine(x + 2, y + 16, 9, color);
    } else if (which == 1) {
        canvas.drawRoundRect(x, y + 1, 16, 12, 3, color); canvas.drawLine(x + 3, y + 13, x + 3, y + 17, color);
        canvas.drawLine(x + 3, y + 17, x + 7, y + 13, color);
    } else if (which == 2) {
        for (int i = 0; i < 3; ++i) { canvas.drawFastHLine(x, y + 3 + i * 5, 16, color); canvas.fillCircle(x + 4 + (i % 2) * 8, y + 3 + i * 5, 2, color); }
    } else if (which == 3) {
        canvas.drawLine(x, y + 12, x + 5, y + 7, color); canvas.drawLine(x + 5, y + 7, x + 9, y + 14, color); canvas.drawLine(x + 9, y + 14, x + 16, y + 2, color);
    } else { canvas.drawCircle(x + 8, y + 8, 8, color); label(x + 6, y + 5, "?", color); }
}
void paint() {
    canvas.fillSprite(Background);
    canvas.drawFastVLine(0, 0, 240, CP_BLUE); canvas.drawFastVLine(319, 0, 240, Pink);
    label(10, 7, "Q-P1NG", CP_BLUE, 2); label(90, 12, "FIELD DECK / " FW_VERSION, Muted);
    char info[64]; snprintf(info, sizeof(info), "%3d%%", batteryPercent); label(278, 12, info, CP_GREEN);
    const char* tabs[] = {"NODE", "CHAT", "SETUP", "LOG", "GUIDE"};
    const uint8_t selected = uint8_t(page) < 5 ? uint8_t(page) : (page == Page::Send ? 1 : 2);
    for (uint8_t i = 0; i < 5; ++i) {
        const int x = 7 + i * 62;
        canvas.fillRoundRect(x, 32, 58, 25, 5, i == selected ? CP_BLUE : Surface);
        label(x + 8, 41, tabs[i], i == selected ? Background : Muted);
        if (tabsFocused && i == selected) canvas.drawRoundRect(x - 1, 30, 60, 29, 6, Pink);
    }
    if (page == Page::Status) {
        box(8, 64, 148, 77, CP_BLUE); glyph(18, 74, 0, CP_BLUE);
        label(40, 76, "LORA / 433 MHz", CP_BLUE); label(18, 97, radioReady ? modeName(mode) : "RADIO ERROR", radioReady ? CP_WHITE : CP_RED, 2);
        snprintf(info, sizeof(info), "SF9 BW250  %d dBm", appliedTxPower); label(18, 126, info, Muted);
        box(164, 64, 148, 77, Pink); glyph(174, 74, 1, Pink); label(198, 76, "PHONE BRIDGE", Pink);
        label(174, 99, deviceConnected ? "BLE LINKED" : (bleLinkConnected ? "PAIRING" : "BLE READY"), CP_WHITE, 2);
        label(174, 126, room.ready ? "ROOM: UNLOCKED" : "ROOM: LOCKED", room.ready ? CP_GREEN : Muted);
        box(8, 148, 304, 38); snprintf(info, sizeof(info), "RX %lu   TX %lu   RELAY %lu", (unsigned long)statRfRxSequences, (unsigned long)statRfTxSequences, (unsigned long)statRelayQueued);
        label(18, 158, info); snprintf(info, sizeof(info), "RSSI %.0f dBm   SNR %.1f   KEY %s", lastRssi, lastSnr, keyboardOnline ? "OK" : "--"); label(18, 173, info, Muted);
        label(12, 198, inTxFragMode ? "RADIO BUSY / processing packet" : "BALL L/R: pages. DOWN or click: open.", inTxFragMode ? CP_AMBER : Muted);
    } else if (page == Page::Chat) {
        box(8, 64, 304, 86, room.ready ? CP_BLUE : Stroke);
        if (messageCount) {
            const auto &m = messages[(messageNext + 5 - messageBack) % 6];
            snprintf(info, sizeof(info), "%s %08lX   %d/%d", m.mine ? "YOU" : "MEMBER", (unsigned long)m.peer, messageCount - messageBack, messageCount);
            label(18, 73, info, m.mine ? CP_BLUE : Pink); wrapped(18, 92, m.text, 47, 4);
        } else { label(18, 74, "STANDALONE ENCRYPTED ROOM", CP_BLUE); wrapped(18, 95, room.ready ? "Type below. Enter reviews, Enter confirms. Share the same room code on both T-Decks." : "SETUP > Create room, or Join room. Phone contacts remain in the Q-P1NG app.", 47, 4, Muted); }
        box(8, 156, 304, 59); snprintf(info, sizeof(info), "DRAFT %u/172  %s", unsigned(draft.length), mode == Mode::Listen ? "RX ONLY" : "ENTER > REVIEW"); label(18, 164, info, CP_BLUE);
        const size_t draftStart = draft.cursor >= 141 ? 47 : 0;
        wrapped(18, 179, draft.text + draftStart, 47, 3);
        const size_t pos = draft.cursor - draftStart;
        canvas.drawFastVLine(18 + int(pos % 47) * 6, 179 + int(pos / 47) * 13, 8, CP_AMBER);
    } else if (page == Page::Settings) {
        const char* names[] = {"Radio mode", "Local TX power", "Display brightness", "Auto dim", "Trackball filter", "Join room", "Create room", "Phone pairing PIN", "Clear room & messages"};
        const uint8_t first = (setting / 5) * 5;
        for (uint8_t i = first; i < min(uint8_t(9), uint8_t(first + 5)); ++i) {
            const int y = 64 + (i - first) * 30; const bool focused = setting == i;
            if (focused) box(8, y, 304, 27, tabsFocused ? Stroke : CP_BLUE);
            label(18, y + 10, names[i], focused ? CP_WHITE : Muted);
            info[0] = 0;
            if (i == 0) snprintf(info, sizeof(info), "%s", modeName(mode));
            if (i == 1) snprintf(info, sizeof(info), "%d dBm", hostTxPower[0]);
            if (i == 2) snprintf(info, sizeof(info), "%u/16", brightness);
            if (i == 3) snprintf(info, sizeof(info), "%s", dimAfter == 0 ? "OFF" : (dimAfter == 15000 ? "15s" : "60s"));
            if (i == 4) snprintf(info, sizeof(info), "%u", sensitivity);
            label(245, y + 10, i < 5 ? info : "OPEN >", CP_BLUE);
        }
    } else if (page == Page::Room) {
        box(8, 64, 304, 151, CP_AMBER); label(18, 75, generatedCode ? "NEW RANDOM ROOM CODE" : "JOIN AN EXISTING ROOM", CP_AMBER, 2);
        wrapped(18, 103, generatedCode ? "Copy this code to the other T-Deck. Keep it private. ENTER activates this room." : "Type the 32 hex characters generated by another T-Deck. This is not a password.", 47, 3, Muted);
        for (size_t line = 0; line < 2; ++line) {
            char grouped[20]{}; size_t n = 0;
            for (size_t i = 0; i < 16 && line * 16 + i < codeEditor.length; ++i) {
                if (i && i % 4 == 0) grouped[n++] = ' ';
                grouped[n++] = codeEditor.text[line * 16 + i];
            }
            label(18, 151 + int(line) * 20, grouped, CP_WHITE, 2);
        }
        label(18, 201, "RAM ONLY / TAB cancels / ENTER joins", CP_AMBER);
    } else if (page == Page::Pair) {
        box(8, 64, 304, 151, Pink); label(20, 77, "PHONE / BLUETOOTH PAIRING", Pink, 2);
        snprintf(info, sizeof(info), "%06lu", (unsigned long)sessionPin); label(88, 113, info, CP_WHITE, 4);
        wrapped(20, 162, "Enter this PIN in Android pairing. It is not your room code. TAB closes.", 46, 3, Muted);
    } else if (page == Page::Send || page == Page::Forget) {
        box(8, 64, 304, 151, CP_AMBER);
        label(18, 76, page == Page::Send ? "SEND TO ROOM MEMBERS?" : "CLEAR THIS ROOM SESSION?", CP_AMBER, 2);
        wrapped(18, 106, page == Page::Send ? draft.text : "The room key, draft and local messages will be removed from RAM. Phone chat and Bluetooth bonds are unaffected.", 47, 5);
        label(18, 197, "ENTER confirms / roll or TAB cancels", CP_AMBER);
    } else if (page == Page::Events) {
        for (uint8_t i = 0; i < eventCount; ++i) { const auto &e = events[(eventNext + 5 - i) % 6]; label(16, 70 + i * 23, ">", e.color); label(30, 70 + i * 23, e.text, e.color); }
        if (!eventCount) label(18, 80, "No events in this session.", Muted);
    } else if (page == Page::Help) {
        const char* titles[] = {"01 / CONTROLS", "02 / PRIVATE ROOMS", "03 / RADIO & PHONE"};
        const char* lines[][9] = {
            {"Pink tab: LEFT/RIGHT changes page", "DOWN or click: enter page controls", "UP at first row: return to page tabs", "Ball up/down: select / message history", "Ball left/right: change / move cursor", "CHAT: ENTER reviews, then confirms", "SETUP: W/S select, A/D change", "TAB or hold ball: next page", "1-5 shortcuts outside text fields"},
            {"Create a random code on one T-Deck.", "Join with the same code on the other.", "Share privately; use a fresh code.", "AES-GCM authenticates room membership.", "It does not prove a person's identity.", "Key and 6 messages live only in RAM.", "Restart/clear removes this session.", "Replay memory resets on restart.", "Receipt = at least one member received."},
            {"MESH: phone bridge + relayed room chat", "DIRECT: no local relays / zero TX hops", "LISTEN: receive only, no acknowledgments", "Peers need the same radio profile.", "433 MHz / SF9 / BW250 / CR4:5", "Local power applies to room messages.", "Phone keeps its own requested TX power.", "Use antenna and permitted RF settings.", "This firmware is for T-Deck / Plus."}
        };
        label(16, 69, titles[helpPage], CP_BLUE, 2);
        for (int i = 0; i < 9; ++i) label(16, 96 + i * 13, lines[helpPage][i], i % 2 ? Muted : CP_WHITE);
    }
    canvas.drawFastHLine(8, 221, 304, Stroke);
    const bool toast = noticeUntil && !qp1ng::due(millis(), noticeUntil);
    label(10, 229, toast ? notice : (tabsFocused ? "L/R page   DOWN open   HOLD next" :
        (page == Page::Chat ? deliveryLabel : "UP to tabs   BALL navigate   ENTER select")), toast ? CP_AMBER : Muted);
}
void serviceDisplay() {
    const uint32_t now = millis();
    if (qp1ng::elapsed(now, lastMetrics, 1000)) {
        lastMetrics = now; dirty = true;
        static uint32_t lastBattery = 0;
        if (qp1ng::elapsed(now, lastBattery, 5000)) { batteryPercent = getBatteryPct(); lastBattery = now; }
    }
    if (dimAfter && !dimmed && qp1ng::elapsed(now, lastInteraction, dimAfter)) { dimmed = true; backlight(1); }
    if (!canvas.created() || isTransmitting || radioActionDone) return;
    if (flushRow >= 240 && dirty && qp1ng::elapsed(now, lastPaint, 50)) {
        frameStarted = now; paint(); dirty = false; flushRow = 0; lastPaint = now;
    }
    if (flushRow < 240) {
        // One stripe per loop: service radio IRQ, USB and BLE between SPI bursts.
        canvas.pushSprite(0, flushRow, 0, flushRow, 320, 16); flushRow += 16;
        if (flushRow >= 240) frameMs = millis() - frameStarted;
    }
}
void init() {
    // The stock Arduino partition scheme stores panic RAM dumps in flash.
    // Never enable local secrets on an old application-only installation.
    roomStorageSafe = esp_partition_find_first(ESP_PARTITION_TYPE_DATA,
        ESP_PARTITION_SUBTYPE_DATA_COREDUMP, nullptr) == nullptr;
    Wire.setTimeOut(4);
    for (uint8_t i = 0; i < 4; ++i) attachInterruptArg(ballPins[i], ballEdge, &ballIndex[i], CHANGE);
    canvas.setColorDepth(16); canvas.setAttribute(PSRAM_ENABLE, true);
    if (!canvas.createSprite(320, 240)) { canvas.setColorDepth(8); canvas.createSprite(320, 240); }
    canvas.setTextWrap(false); batteryPercent = getBatteryPct(); backlight(brightness); wake();
    if (!canvas.created()) { tft.fillScreen(CP_BLACK); tft.setTextColor(CP_WHITE); tft.drawString("Display memory unavailable", 8, 20, 2); }
    event("Q-P1NG FIELD DECK " FW_VERSION, CP_BLUE);
}
} // namespace deck

void recordExperienceEvent(const char* text, uint16_t color) { deck::event(text, color); }
bool localModeAllowsTx() { return deck::mode != deck::Mode::Listen; }
bool localRelayEnabled() { return deck::mode == deck::Mode::Mesh; }
uint8_t localHopBudget(uint8_t legacy) { return deck::mode == deck::Mode::Direct ? 0 : legacy; }
void handleRoomPacket(const uint8_t* packet, size_t length) { deck::receive(packet, length); }
void notifyLocalTx(bool success) {
    if (!deck::localTx) return;
    if (deck::localSequence && deck::pending.active && deck::pending.sequence == deck::localSequence) {
        deck::deliveryLabel = success ? "RF sent. Waiting for receipt..." : "RF error. Retrying...";
        deck::pending.next = millis() + 12000;
    }
    deck::localTx = false; deck::localSequence = 0; deck::dirty = true;
}
void serviceExperience() { deck::input(); deck::serviceChat(); deck::serviceDisplay(); }

bool handleLocalUsbCommand(const String& cmd, Print& out) {
    if (cmd == "QP1NG_USB_DIAG") {
        out.printf("QP1NG_TDECK_DIAG|page=%u|mode=%s|keyboard=%u|keys=%lu|ball=%lu|clicks=%lu|room=%u|messages=%u|pending=%u|heap=%u|psram=%u|ui=%u|test=%u|up=%lu|down=%lu|left=%lu|right=%lu|ram_only=%u|nav=%u|option=%u|ui_ms=%lu|input_gap=%lu\n",
            unsigned(deck::page), deck::modeName(deck::mode), deck::keyboardOnline, (unsigned long)deck::keyCount,
            (unsigned long)deck::ballCount, (unsigned long)deck::clickCount, deck::room.ready, deck::messageCount,
            deck::pending.active, ESP.getFreeHeap(), ESP.getFreePsram(), deck::canvas.created(), QP1NG_TEST_HOOKS,
            (unsigned long)deck::ballDirections[0], (unsigned long)deck::ballDirections[1],
            (unsigned long)deck::ballDirections[2], (unsigned long)deck::ballDirections[3], deck::roomStorageSafe,
            deck::tabsFocused, deck::setting, (unsigned long)deck::frameMs, (unsigned long)deck::maxInputGap);
        return true;
    }
#if QP1NG_TEST_HOOKS
    // Compiled OUT of distributable releases; only the local hardware test build.
    if (cmd.startsWith("QP1NG_TEST_SEAL|")) {
        uint8_t packet[deck::Room::MaxPacket];
        const String text = cmd.substring(16);
        const size_t length = deck::room.seal(1, reinterpret_cast<const uint8_t*>(text.c_str()), text.length(), deck::room.reserveSequence(), packet);
        out.print("QP1NG_TEST_PACKET|");
        for (size_t i = 0; i < length; ++i) out.printf("%02X", packet[i]);
        out.println(); deck::wipe(packet, sizeof(packet)); return true;
    }
    if (cmd.startsWith("QP1NG_TEST_KEY|")) { deck::key(uint8_t(cmd.substring(15).toInt())); out.println("QP1NG_TEST_OK"); return true; }
    if (cmd.startsWith("QP1NG_TEST_BALL|")) { int n = cmd.substring(16).toInt(); if (n >= 0 && n < 4) deck::navigate(n); out.println("QP1NG_TEST_OK"); return true; }
    if (cmd.startsWith("QP1NG_TEST_RX|")) {
        uint8_t data[220]; size_t n = 0;
        if (decodeHexFrame(cmd.substring(14), data, sizeof(data), n)) deck::receive(data, n);
        deck::wipe(data, sizeof(data)); out.println("QP1NG_TEST_OK"); return true;
    }
    if (cmd.startsWith("QP1NG_TEST_SCREEN|")) {
        const int row = cmd.substring(18).toInt();
        if (row >= 0 && row < 240 && deck::page != deck::Page::Room && deck::page != deck::Page::Pair) {
            out.print("QP1NG_SCREEN|");
            for (int x = 0; x < 320; ++x) { const uint16_t px = deck::canvas.readPixel(x, row); out.printf("%04X", px); }
            out.println();
        }
        return true;
    }
#endif
    return false;
}
