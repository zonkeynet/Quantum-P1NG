#pragma once
#include "TDeckModel.h"
#include <mbedtls/gcm.h>
#include <mbedtls/sha256.h>
#include <esp_system.h>

namespace deck {
// QDT1 is a separate application envelope, carried by unchanged v15 RF fragments.
// A shared room code authenticates membership, not a person's identity.
class Room {
    uint8_t key[32]{};
    uint32_t nextSequence = 0;
public:
    static constexpr size_t Header = 32, Tag = 16, MaxPacket = Header + TextLimit + Tag;
    bool ready = false;
    uint64_t sender = 0;
    ReplayWindow replay;
    void clear() { wipe(key, sizeof(key)); replay.clear(); sender = 0; nextSequence = 0; ready = false; }
    bool join(const uint8_t (&code)[16]) {
        clear();
        // Domain separation. Input MUST be a device-generated random 128-bit code,
        // not a human password; this is deliberately not a password KDF.
        uint8_t material[32] = {'Q','P','1','N','G','-','T','D','E','C','K','-','R','O','O','M'};
        memcpy(material + 16, code, 16);
        const int status = mbedtls_sha256_ret(material, sizeof(material), key, 0);
        wipe(material, sizeof(material));
        if (status != 0) { clear(); return false; }
        do { esp_fill_random(&sender, sizeof(sender)); } while (!sender);
        ready = true; return true;
    }
    uint32_t reserveSequence() {
        if (!ready || nextSequence == UINT32_MAX) return 0;
        return ++nextSequence;
    }
    static bool recognizes(const uint8_t* data, size_t size) {
        return size >= Header + Tag && size <= MaxPacket && memcmp(data, "QDT1", 4) == 0;
    }
    size_t seal(uint8_t kind, const uint8_t* plain, size_t length, uint32_t sequence, uint8_t* out) {
        if (!ready || !sequence || length > TextLimit || !length ||
            (kind != 1 && kind != 2) || (kind == 2 && length != 12)) return 0;
        memset(out, 0, Header); memcpy(out, "QDT1", 4); out[4] = kind; out[5] = uint8_t(length);
        write64(out + 8, sender); write32(out + 16, sequence);
        esp_fill_random(out + 20, 12); // Fresh nonce also on retries.
        mbedtls_gcm_context ctx; mbedtls_gcm_init(&ctx);
        int rc = mbedtls_gcm_setkey(&ctx, MBEDTLS_CIPHER_ID_AES, key, 256);
        if (!rc) rc = mbedtls_gcm_crypt_and_tag(&ctx, MBEDTLS_GCM_ENCRYPT, length, out + 20, 12,
            out, Header, plain, out + Header, Tag, out + Header + length);
        mbedtls_gcm_free(&ctx);
        if (rc) { wipe(out, MaxPacket); return 0; }
        return Header + length + Tag;
    }
    bool open(const uint8_t* packet, size_t size, uint8_t (&plain)[TextLimit + 1], ReplayResult& result) {
        wipe(plain, sizeof(plain));
        if (!ready || !recognizes(packet, size) || packet[6] || packet[7] ||
            (packet[4] != 1 && packet[4] != 2) || packet[5] == 0 ||
            size != Header + packet[5] + Tag || (packet[4] == 2 && packet[5] != 12) ||
            read64(packet + 8) == sender) return false;
        mbedtls_gcm_context ctx; mbedtls_gcm_init(&ctx);
        int rc = mbedtls_gcm_setkey(&ctx, MBEDTLS_CIPHER_ID_AES, key, 256);
        if (!rc) rc = mbedtls_gcm_auth_decrypt(&ctx, packet[5], packet + 20, 12, packet, Header,
            packet + Header + packet[5], Tag, packet + Header, plain);
        mbedtls_gcm_free(&ctx);
        if (rc) { wipe(plain, sizeof(plain)); return false; }
        if (packet[4] == 1) {
            for (size_t i = 0; i < packet[5]; ++i) if (plain[i] < 32 || plain[i] > 126) {
                wipe(plain, sizeof(plain)); return false;
            }
        }
        result = replay.accept(read64(packet + 8), read32(packet + 16));
        if (result == ReplayResult::Stale || result == ReplayResult::Full) { wipe(plain, sizeof(plain)); return false; }
        return true;
    }
    ~Room() { clear(); }
};
static_assert(Room::MaxPacket == 220, "Standalone text must fit one RF fragment");
} // namespace deck
