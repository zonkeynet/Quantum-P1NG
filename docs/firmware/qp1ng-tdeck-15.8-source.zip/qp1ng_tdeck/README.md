# Q-P1NG Field Deck 15.8

Target: original LilyGO T-Deck / T-Deck Plus with SX1262, 16 MB flash and
8 MB OPI PSRAM. This release uses the existing **433 MHz / SF9 / BW250 /
CR4:5 / sync 0x14** profile. It is not a universal 868/915 MHz image, a
Meshtastic image, or a T-Deck Pro / Max build.

## Physical controls

- Pink outline on the page tabs: roll left/right to change page, down or click
  to enter its controls. Roll up from the first setting or an empty chat to
  return to the tabs. This navigation never requires a TAB key.
- TAB or hold the trackball for 650 ms: next page.
- Trackball up/down: select an option or browse the six local messages.
- Trackball left/right: change a setting or move the text cursor.
- Click / Enter: select; chat requires Enter to review and a second Enter to send.
- Backspace: edit. Escape: cancel / return to the status page.
- Outside text fields, keys 1–5 open Node, Chat, Setup, Log, Guide.
- In Setup, W/S (or K/J) select; A/D (or H/L) change the value.

Setup includes Mesh / Direct / Listen mode, local transmit power, 16 brightness
levels, auto dim, trackball filter, room setup, phone pairing PIN and confirmed
session removal. Settings are session-only and boot into the compatible Mesh
profile. Phone packets retain each host's own selected power.
Display updates yield between 16-row SPI stripes; only an active screen refresh
uses the shorter loop delay. Radio events are serviced before each stripe.
Trackball filtering defaults to one pulse. Slow pulses accumulate for up to
250 ms; dominant-axis navigation is limited to one step per 70 ms, without a
queued movement backlog. Higher filter values require more pulses per step.

## Standalone rooms

On one device choose **Setup → Create room**, privately copy its random 32-digit
hexadecimal code to **Setup → Join room** on the other, then confirm both.
The code is random 128-bit key material, **not a human password**. Use a fresh
code for every session. Up to 172 printable ASCII characters fit one RF fragment.
Keys, drafts, six recent messages and replay state live only in RAM. Bluetooth
bond records remain in NVS; resetting or clearing a room does not clear bonds.

Room messages use a separate `QDT1` AES-256-GCM envelope. Existing phone traffic
remains opaque to firmware and is unchanged. The room does not import Android
contacts or chat identity keys: room members share a secret and can impersonate
one another. A receipt means **at least one room member** received the message,
not every member. There are at most three transmissions, 12 seconds apart after
radio completion, with an overall 60-second deadline. Listen mode sends no
messages, relays or receipts. Direct mode sets outgoing hop budgets to zero and
does not relay; the default Mesh mode retains the existing relay policy.

Replay protection is a 64-sequence sliding window for up to 32 sender sessions;
entries are never evicted to admit a replay. It resets when the room is cleared
or the board restarts. **Reuse of an old code after a restart permits old packets
to be replayed.** This group protocol offers neither forward secrecy nor verified
individual identities. RAM-only storage does not guarantee resistance to physical
memory extraction. Never describe the board as untraceable or forensically empty.
The checked-in `partitions.csv` omits the stock Arduino core-dump partition,
which would otherwise allow a panic to save RAM to flash. Local rooms and
draft entry stay disabled if a device still has that old partition. A full
installation is required; the phone's opaque bridge remains available.

Wire format, little-endian integers: `QDT1` (4), kind (1: text / 2: receipt),
plaintext length (1), zero reserved bytes (2), random sender session (8), sequence
(4), random nonce (12), ciphertext (1–172), GCM tag (16). The 32-byte header is
authenticated as AAD. Receipts encrypt original sender (8) and sequence (4).
Retransmissions retain the logical sequence with a new random nonce; authenticated
duplicates are acknowledged without being displayed again. SHA-256 of the 16-byte
ASCII domain `QP1NG-TDECK-ROOM` followed by the 16-byte room code derives the key.
Cryptographic operations use the existing ESP32 mbedTLS implementation.

## Release build and fresh flash

`python tools/tdeck/build.py` builds the release with the checked-in
`TDeckDisplay.h` configuration. `python tools/tdeck/package.py` creates the
complete website package in `diagnostics/tdeck-2026-10-13/package-release`.
Builds with `--test-hooks` are exclusively local test images and must never be
published; the packaging check rejects test command strings in a release.

The merged ESP32-S3 image goes at **0x0** and contains bootloader (0x0), partition
table (0x8000), OTA selection `boot_app0.bin` (0xe000), and application (0x10000).
The website manifest performs a **fresh install that erases all flash**, including
Bluetooth bonds and prior firmware storage. Keep a verified backup first. The
merged image is not a data-preserving update. Source archive, individual binaries,
release metadata and SHA-256 checksums accompany the merged image.

The isolated esptool 5.5.0 in `tmp/tdeck-tools` is used for real backups/flashes;
the old installed 4.5.1 has a known slow ESP32-S3 USB read path. `tools/tdeck/device.py`
requires a full verified per-board backup before writing and checks the board
fingerprint. The `app` action is only for this known 0x10000 test layout after a
fresh install. Never use it on an unknown OTA layout.

`QP1NG_USB_DIAG` returns only page/mode, input counters, room/history counts and
free memory. It does not expose message text, room codes, pairing PINs or keys.
Production firmware has no remote key injection or screenshot command.

The downloadable source archive also builds independently. Install the pinned
versions above, select **ESP32S3 Dev Module**, USB CDC on boot, 16 MB flash,
OPI PSRAM and the 3 MB app / 9 MB FAT partition scheme. For Arduino CLI, pass
`--build-property "compiler.cpp.extra_flags=-DQP1NG_TEST_HOOKS=0 -include /absolute/path/to/qp1ng_tdeck/TDeckDisplay.h"`
to `arduino-cli compile` with this FQBN:
`esp32:esp32:esp32s3:USBMode=hwcdc,CDCOnBoot=cdc,FlashSize=16M,PSRAM=opi,PartitionScheme=app3M_fat9M_16MB`.
Use a source path without spaces for this command. The forced include supplies
the same TFT configuration to both the sketch and TFT_eSPI; an IDE-only build
without that setting is not equivalent.
Keep `partitions.csv` beside the sketch; Arduino CLI automatically uses it.
The application and NVS offsets are unchanged; the final 64 KiB are unassigned.

## Existing bridge compatibility

Maintained source: `qp1ng_tdeck.ino`, with bounded host/RF framing in
`LoRaProtocol.h`. Original external sketches are not overwritten.

Build the current release and run the unchanged protocol tests from the repository root:

```text
python tools/tdeck/build.py
tools\lora-review\Test-Protocol.cmd
```

The installed toolchain uses ESP32 Arduino 2.0.14, RadioLib 7.1.2 and TFT_eSPI
2.5.43 with the checked-in T-Deck display configuration. The older
`tools/lora-review/build_firmware.py` and preservation helper are retained for
historical diagnostics. Do not use their application-only workflow as a fresh
install: that helper reads the existing active application slot and keeps the
original partitions and Bluetooth bonds. The new website package deliberately
uses the complete, data-erasing installation described above.

## Host commands

- `QP1NG_USB_HELLO` / `QP1NG_USB_STATUS`: allowlisted identity and radio state.
- `QP1NG_USB_PING`: liveness.
- `TX_POWER=-9` through `TX_POWER=22`: strict signed decimal configuration.
  USB replies `QP1NG_TDECK_POWER|state=ok|applied=22|max=22|seq=...`.
  Invalid or busy commands do not change the selected level.
- `QP1NG_USB_FRAME|<hex>`: five-byte host header plus payload. Android uses
  100-byte chunks so command lines also fit legacy 256-byte CDC queues.
- `QP1NG_USB_TX_STATUS`: last locally completed host RF transmission.

BLE power commands use the authenticated UART RX characteristic. The optional
status characteristic is UUID `6E400004-B5A3-F393-E0A9-E50E24DCCA9E`.
Bonded clients with a cached older service table use the existing UART handles:
write `QP1NG_STATUS=hhhh` (four hex digits), then receive exactly 20 notification
bytes: `QS`, the two-byte big-endian request token, and the 16-byte v3 status.
Replies with an old token must be discarded. This exchange fits ATT MTU 23 and
does not alter the radio-fragment assembler or start a radio transmission.

V3 status: `QL`, version 3, state (0 idle / 1 queued / 2 sent / 3 error),
FNV32 little-endian at 4–7, packet length big-endian at 8–9, ready at 10, busy at
11, signed applied dBm at 12, power result at 13 (0 none / 1 ok / 2 busy /
3 invalid / 4 error), signed requested dBm at 14, sequence modulo 256 at 15.

Power defaults to 10 dBm at boot. The app saves its own preference and applies
it before each packet. USB and BLE keep separate requested levels to prevent
one host from changing the power of another host's assembled packet.

## Verification and preservation

`tools/lora-review/device_firmware.py` backs up and verifies only the active
application partition, leaving NVS, Bluetooth bonds and partition tables intact.
Original backups and per-device receipts live in `tmp/lora-review` and must not
be interchanged. Enter the bootloader using trackball centre + RESET; after a
verified write, press RESET alone.

`verify_power.py` checks real command acknowledgements without transmitting RF.
`verify_radio.py` runs encrypted synthetic packets between Samsung/BLE and
PC/USB through two T-Decks. Its three round trips cover 10 dBm, 22 dBm and
restoration of the phone's original setting. See
`docs/LORA_REVIEW_2026-09-27.md` for results and the distinction between local
RF completion and actual recipient receipt.
