#pragma once
#include <stdint.h>
#include <stddef.h>
#include <string.h>

namespace deck {
constexpr size_t TextLimit = 172;
inline void wipe(void* data, size_t length) {
    volatile uint8_t* p = static_cast<volatile uint8_t*>(data);
    while (length--) *p++ = 0;
}

// Fixed storage: key repeats and malformed input cannot grow the heap.
template<size_t Capacity> struct Editor {
    char text[Capacity + 1]{};
    size_t length = 0, cursor = 0;
    void clear() { wipe(text, sizeof(text)); length = cursor = 0; }
    bool insert(uint8_t c) {
        if (c < 32 || c > 126 || length == Capacity) return false;
        memmove(text + cursor + 1, text + cursor, length - cursor + 1);
        text[cursor++] = char(c); ++length; return true;
    }
    bool backspace() {
        if (!cursor) return false;
        memmove(text + cursor - 1, text + cursor, length - cursor + 1);
        text[length--] = 0; --cursor; return true;
    }
    void move(int direction) {
        if (direction < 0 && cursor) --cursor;
        else if (direction > 0 && cursor < length) ++cursor;
    }
    bool meaningful() const {
        for (size_t i = 0; i < length; ++i) if (text[i] != ' ') return true;
        return false;
    }
};

enum class ReplayResult { Fresh, Duplicate, Stale, Full };
// Authenticated frames only. No eviction: an old sender must not become new again.
struct ReplayWindow {
    struct Peer { uint64_t sender = 0; uint32_t highest = 0; uint64_t seen = 0; } peers[32]{};
    void clear() { wipe(peers, sizeof(peers)); }
    ReplayResult accept(uint64_t sender, uint32_t sequence) {
        if (!sender || !sequence) return ReplayResult::Stale;
        Peer* slot = nullptr;
        for (auto &p : peers) if (p.sender == sender) { slot = &p; break; }
        if (!slot) {
            for (auto &p : peers) if (!p.sender) { slot = &p; break; }
            if (!slot) return ReplayResult::Full;
            slot->sender = sender; slot->highest = sequence; slot->seen = 1;
            return ReplayResult::Fresh;
        }
        if (sequence > slot->highest) {
            const uint32_t shift = sequence - slot->highest;
            slot->seen = shift >= 64 ? 1 : (slot->seen << shift) | 1;
            slot->highest = sequence; return ReplayResult::Fresh;
        }
        const uint32_t behind = slot->highest - sequence;
        if (behind >= 64) return ReplayResult::Stale;
        const uint64_t bit = uint64_t(1) << behind;
        if (slot->seen & bit) return ReplayResult::Duplicate;
        slot->seen |= bit; return ReplayResult::Fresh;
    }
};

inline uint32_t read32(const uint8_t* p) {
    return uint32_t(p[0]) | uint32_t(p[1]) << 8 | uint32_t(p[2]) << 16 | uint32_t(p[3]) << 24;
}
inline uint64_t read64(const uint8_t* p) { return read32(p) | uint64_t(read32(p + 4)) << 32; }
inline void write32(uint8_t* p, uint32_t n) { for (int i = 0; i < 4; ++i) p[i] = uint8_t(n >> (8 * i)); }
inline void write64(uint8_t* p, uint64_t n) { write32(p, uint32_t(n)); write32(p + 4, uint32_t(n >> 32)); }
inline int hexDigit(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}
inline bool roomCode(const char* text, size_t length, uint8_t (&out)[16]) {
    if (length != 32) return false;
    uint8_t parsed[16]{};
    for (size_t i = 0; i < 16; ++i) {
        const int a = hexDigit(text[i * 2]), b = hexDigit(text[i * 2 + 1]);
        if (a < 0 || b < 0) { wipe(parsed, sizeof(parsed)); return false; }
        parsed[i] = uint8_t(a * 16 + b);
    }
    memcpy(out, parsed, sizeof(parsed)); wipe(parsed, sizeof(parsed)); return true;
}
enum class Mode : uint8_t { Mesh, Direct, Listen };
inline const char* modeName(Mode m) { return m == Mode::Mesh ? "MESH" : (m == Mode::Direct ? "DIRECT" : "LISTEN"); }
enum class Page : uint8_t { Status, Chat, Settings, Events, Help, Room, Pair, Send, Forget };

// UI navigation, not an inertial mouse. Retain small pulses across polling
// windows, choose the dominant axis, and never queue a long movement backlog.
struct TrackballMotion {
    int x = 0, y = 0;
    uint32_t lastMotion = 0, lastStep = 0;
    bool stepped = false;
    void clear() { x = y = 0; }
    static int bounded(int value) { return value < -64 ? -64 : (value > 64 ? 64 : value); }
    int update(const uint16_t (&edges)[4], uint32_t now, uint8_t threshold) {
        if (uint32_t(now - lastMotion) > 250) clear();
        if (edges[0] || edges[1] || edges[2] || edges[3]) {
            x = bounded(x + int(edges[3]) - int(edges[2]));
            y = bounded(y + int(edges[1]) - int(edges[0]));
            lastMotion = now;
        }
        if (stepped && uint32_t(now - lastStep) < 70) return -1;
        const int ax = x < 0 ? -x : x, ay = y < 0 ? -y : y;
        const int limit = threshold ? threshold : 1;
        if (ax < limit && ay < limit) return -1;
        const int direction = ax > ay ? (x < 0 ? 2 : 3) : (y < 0 ? 0 : 1);
        clear(); lastStep = now; stepped = true;
        return direction;
    }
};
} // namespace deck
