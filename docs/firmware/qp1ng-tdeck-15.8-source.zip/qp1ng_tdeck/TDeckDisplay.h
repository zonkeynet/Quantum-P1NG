#pragma once
// Checked-in T-Deck display configuration; passed to ALL C++ translation units.
// Pinout and panel options follow LilyGO Setup210. No global library edits.
#define USER_SETUP_LOADED
#define USER_SETUP_ID 210
#define ST7789_DRIVER
#define TFT_WIDTH 240
#define TFT_HEIGHT 320
#define TFT_RGB_ORDER TFT_RGB
#define INIT_SEQUENCE_2
#define TFT_MISO 38
#define TFT_MOSI 41
#define TFT_SCLK 40
#define TFT_CS 12
#define TFT_DC 11
#define TFT_RST -1
#define TFT_BACKLIGHT_ON 1
#define LOAD_GLCD
#define LOAD_FONT2
#define LOAD_FONT4
#define SPI_FREQUENCY 40000000
#define SPI_READ_FREQUENCY 20000000
